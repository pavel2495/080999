import {AsyncLocalStorage} from 'node:async_hooks';
const deadlines=new AsyncLocalStorage<number>();
export function withRequestBudget<T>(milliseconds:number,run:()=>T):T{return deadlines.run(Date.now()+milliseconds,run);}
export function requestDeadline(){return deadlines.getStore()??Infinity;}
export function remainingRequestTime(){return Math.max(0,requestDeadline()-Date.now());}

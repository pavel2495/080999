export type City='msk'|'spb';
export type Product={id:string;brand?:string;name:string;article:string;url:string;image:string;images?:string[];price:number|null;stock:'in'|'out'|'unknown';quantity:string;minimumQuantity:number|null;description:string;specs:Record<string,string>;category:string;categoryName?:string;checkedAt:string;city?:City;delivery?:string;pickup?:string};
export type Match={product:Product;level:'matched'|'review';reasons:string[];differences:string[];missing:string[];score:number};
export type SearchItem={id:string;brand?:string;name:string;url:string;image:string;description:string;available?:boolean;categories?:{id:string;name:string}[]};
export type PriceRange={min:number|null;max:number|null};
export type BrandMode='any'|'same'|'other';
export type ScanCursor={page:number;seen:string[];sourceId:string;city:City;plan:string};

import type {Product,Match,PriceRange,BrandMode,SearchItem} from './types.ts';
import {clean,normalize,field,numeric,capacity,canonical,ddr,resolution,tokens,ports,gpuChip} from './normalize.ts';
import {profileFor,family,rulesFor,type Rule} from './profiles.ts';
export {family,profileFor,rulesFor};
export {clean,normalize,field,ports,gpuChip};
export function sameProduct(a:Product,b:Product){return a.id===b.id||a.url===b.url||!!(a.brand&&b.brand&&canonical(a.brand)===canonical(b.brand)&&normalize(a.name)===normalize(b.name))||!!(a.brand&&b.brand&&canonical(a.brand)===canonical(b.brand)&&a.article&&b.article&&normalize(a.article)===normalize(b.article));}
export function priceRange(min:string|null,max:string|null):PriceRange{const parse=(s:string|null)=>s===null||s.trim()===''?null:Number(s);const r={min:parse(min),max:parse(max)};if(Object.values(r).some(v=>v!==null&&(!Number.isFinite(v)||v<0||v>1e10))||r.min!==null&&r.max!==null&&r.min>r.max)throw new Error('Укажите корректную цену «от — до» в рублях.');return r;}
export function withinPrice(price:number|null,range:PriceRange){return range.min===null&&range.max===null||price!==null&&(range.min===null||price>=range.min)&&(range.max===null||price<=range.max);}
export function brandMode(value:unknown):BrandMode{if(value===undefined||value===null||value===''||value==='any')return 'any';if(value==='same'||value==='other')return value;throw new Error('Некорректный режим бренда.');}
export function brandAllowed(a:Product,b:Product,mode:BrandMode){if(mode==='any')return true;if(!a.brand||!b.brand)return false;return (canonical(a.brand)===canonical(b.brand))===(mode==='same');}
function ruleValue(p:Product,r:Rule){let v=field(p,r.keys);if(!v&&r.kind==='gpu')v=p.name;if(!v&&r.kind==='ports')v=Object.entries(p.specs).filter(([k,val])=>/^Количество (HDMI|DisplayPort|DVI|VGA)/i.test(k)&&numeric(val)>0).map(([k])=>k.replace('Количество ','')).join(', ');if(!v&&r.label==='Технология печати'){const n=normalize(p.name);if(/лазерн/.test(n))v='Лазерная';else if(/струйн/.test(n))v='Струйная';}return v;}
function matrix(s:string){return canonical(s.replace(/fast |rapid |nano |advanced |tft /gi,'').replace(/ah-ips|ads-ips/i,'ips'));}
function speed(s:string){const n=normalize(s),v=numeric(s);return /гбит|gbps|gbit|\d\s*g\s*(?:медь|оптика)/.test(n)?v*1000:/кбит|kbps/.test(n)?v/1000:v;}
function connector(s:string){return normalize(s).replace(/display\s*port/g,'dp').replace(/displayport/g,'dp').replace(/\b\d+(?:\.\d+)?\s*(?:гбит|мбит|gbps|gbit|гб|g)(?:\/с)?/g,'').replace(/hdmi\s*\d+(?:\.\d+)?/g,'hdmi').replace(/usb\s*\d+(?:\.\d+)?/g,'usb').replace(/pci-e|pci express/g,'pcie').replace(/[^a-zа-я0-9+]/g,'');}
function os(s:string){const n=normalize(s);return /без ос|не установлена|dos/.test(n)?'no-os':n.match(/windows|android|ios|linux|macos|astra|redos|ред ос/)?.[0]||canonical(s);}
function valuesEqual(a:string,b:string,r:Rule){if(r.kind==='resolution')return resolution(a)===resolution(b);if(r.kind==='matrix')return matrix(a)===matrix(b);if(r.kind==='ddr')return ddr(a)===ddr(b);if(r.kind==='form')return canonical(a)===canonical(b);if(r.kind==='connector')return connector(a)===connector(b);if(r.kind==='os')return os(a)===os(b);return canonical(a)===canonical(b);}
const strictCategories=new Set(['battery','ink','toner','cartridge','adapter','cable','mount']);
export function compareProducts(source:Product,candidate:Product):Match|null{
 const f=family(source),profile=profileFor(source);if(sameProduct(source,candidate)||candidate.stock!=='in'||f!==family(candidate)||source.city&&candidate.city&&source.city!==candidate.city)return null;
 if((!profile||strictCategories.has(f))&&source.category&&candidate.category&&source.category!==candidate.category)return null;
 const reasons:string[]=[],missing:string[]=[],differences:string[]=[];const explained=new Set<string>();let earned=0,total=0,evidence=0,criticalKnown=0,importantMisses=0;
 const rs=rulesFor(source);
 for(const r of rs){const a=ruleValue(source,r),b=ruleValue(candidate,r);if(!a){if(r.required||r.priority==='critical')missing.push(r.label+': нет данных у исходного');continue;}total+=r.weight;if(!b){if(r.priority!=='secondary'||r.required)missing.push(r.label+': нет данных у аналога');continue;}evidence++;
  let equivalent=valuesEqual(a,b,r),okay=equivalent,closeness=equivalent?1:0,forceReview=false;
  if(r.kind==='gpu'){const x=gpuChip(a),y=gpuChip(b);if(!x||!y){const av=field(source,r.keys),bv=field(candidate,r.keys);if(!av||!bv){missing.push('Модель графического процессора: нет точных данных');continue;}okay=equivalent=canonical(av.replace(/nvidia|geforce|amd|radeon|intel/ig,''))===canonical(bv.replace(/nvidia|geforce|amd|radeon|intel/ig,''));}else okay=equivalent=x===y;closeness=equivalent?1:0;}
  if(r.kind==='capacity'||r.kind==='minimum'||r.kind==='speed'){const av=r.kind==='capacity'?capacity(a):r.kind==='speed'?speed(a):numeric(a),bv=r.kind==='capacity'?capacity(b):r.kind==='speed'?speed(b):numeric(b);if(!Number.isFinite(av)||!Number.isFinite(bv)||av<=0){missing.push(r.label+': не удалось сопоставить единицы');continue;}const ratio=bv/av;equivalent=Math.abs(ratio-1)<.005;okay=ratio>=(r.floor??(r.priority==='critical'?1:0));closeness=equivalent?1:ratio>=1?.94:Math.max(0,ratio*.8);if(ratio<1)forceReview=true;if(r.label==='Длина'&&ratio>1){closeness=1/(1+Math.abs(Math.log(ratio))*.6);if(ratio>1.5)forceReview=true;}if(!okay&&r.priority==='important'&&r.floor!==undefined)return null;}
  if(r.kind==='diagonal'){const delta=Math.abs(numeric(a)-numeric(b));if(!Number.isFinite(delta)){missing.push(r.label+': нет числовых данных');continue;}okay=delta<=(r.tolerance??.5);equivalent=delta<.01;closeness=okay?Math.max(.65,1-delta/(r.tolerance||.5)*.25):0;}
  if(r.kind==='ports'){const x=ports(a),y=ports(b);okay=x.every(v=>y.includes(v));equivalent=okay&&y.length===x.length;closeness=okay?1:0;}
  if(r.kind==='set'){const x=tokens(a),y=tokens(b);okay=x.every(v=>y.includes(v));equivalent=okay&&y.every(v=>x.includes(v));closeness=okay?1:x.filter(v=>y.includes(v)).length/Math.max(1,x.length);}
  if(r.kind==='processor'){equivalent=canonical(a)===canonical(b);okay=true;closeness=equivalent?1:.25;if(!equivalent){missing.push(r.label+': сравнить производительность '+a+' и '+b);forceReview=true;}}
  if(!okay&&r.priority==='critical')return null;
  if(okay){earned+=r.weight*closeness;if(r.priority==='critical')criticalKnown++;reasons.push(r.label+': '+b);}else{importantMisses++;if(r.priority==='important')missing.push(r.label+': '+a+' → '+b);}
  if(!equivalent){const line=r.label+': '+a+' → '+b+(r.kind==='diagonal'&&okay?' (близкий размер)':'');differences.push(line);for(const k of r.keys)explained.add(normalize(k));if(forceReview&&r.kind!=='processor')missing.push(r.label+': '+b);}
 }
 // Generic categories require actual technical evidence, never only a shared brand, colour or title.
 if(!profile&&(evidence<2||criticalKnown<1||earned/Math.max(1,total)<.55))return null;
 if(profile&&evidence<2)return null;
 if(!profile)missing.push('Категория без специального профиля: проверить назначение и совместимость');
 if(profile?.review)missing.push(profile.review);
 if(source.brand&&candidate.brand&&canonical(source.brand)!==canonical(candidate.brand))differences.push('Бренд: '+source.brand+' → '+candidate.brand);
 const secondary:string[]=[];for(const[k,v]of Object.entries(source.specs)){const b=field(candidate,[k]);if(b&&!explained.has(normalize(k))&&canonical(v)!==canonical(b)&&!rs.some(r=>r.keys.some(key=>normalize(key)===normalize(k))))secondary.push(k+': '+v+' → '+b);}
 differences.push(...secondary);
 if(f==='motherboard'&&/(?:btf|project zero|stealth)/i.test(source.name+' '+candidate.name))missing.push('Расположение разъёмов питания и совместимость с корпусом');
 const confidence=earned/Math.max(1,total);if(profile&&criticalKnown===0)missing.push('Критические параметры не подтверждены');
 const technical=confidence*100-importantMisses*4-Math.min(12,missing.length*2);
 const pricePenalty=source.price&&candidate.price?Math.min(2,Math.abs(Math.log(candidate.price/source.price))):0;
 return{product:candidate,level:missing.length?'review':'matched',reasons:[...new Set(reasons)],differences:[...new Set(differences)],missing:[...new Set(missing)],score:Math.round((technical-pricePenalty)*100)/100};
}
export function queriesFor(p:Product){const profile=profileFor(p),f=profile?.id;const out:string[]=[];
 if(f==='gpu'){const chip=gpuChip(field(p,['Графический процессор'])||p.name);if(chip)out.push('Видеокарта '+chip);}
 else if(f==='motherboard')out.push(['Материнская плата',field(p,['Сокет','Socket']),field(p,['Тип поддерживаемой памяти','Тип памяти'])].filter(Boolean).join(' '));
 else if(f==='ssd'||f==='hdd'||f==='external-drive'||f==='memory-card')out.push([profile!.label,field(p,['Объем накопителя','Объем']),field(p,['Интерфейс','Интерфейс подключения'])].filter(Boolean).join(' '));
 else if(f==='monitor'||f==='tv'||f==='projector')out.push([profile!.label,field(p,['Разрешение','Разрешение экрана','Максимальное разрешение'])].filter(Boolean).join(' '));
 else if(['cartridge','toner','ink'].includes(f||'')){const models=field(p,['Совместимость с моделями','Совместимость']);if(models)out.push(profile!.label+' '+models.split(/[,;]/)[0]);}
 else{const technical=rulesFor(p).filter(r=>r.priority==='critical').map(r=>ruleValue(p,r)).filter(v=>v&&v.length<45).slice(0,2);if(technical.length)out.push([profile?.label||p.categoryName||'',...technical].join(' '));}
 const broad=p.categoryName||profile?.label||p.name.replace(p.brand||'','').replace(/\[[^\]]+\]/g,'').split(' ').slice(0,3).join(' ');if(broad)out.push(broad);
 return [...new Set(out.map(s=>clean(s).slice(0,220)).filter(Boolean))].slice(0,3);
}
export function summaryScore(p:Product,c:SearchItem){const text=normalize(c.name+' '+c.description),profile=profileFor(p);let score=family({name:c.name})===family(p)?5:0;for(const r of rulesFor(p)){const v=field(p,r.keys);if(!v)continue;if(r.kind==='gpu'){const chip=gpuChip(v);score+=chip&&gpuChip(c.name)===chip?100:-100;}else if(r.kind==='resolution'){if(resolution(text).includes(resolution(v)))score+=25;}else if(r.kind==='ddr'){if(text.includes(ddr(v)))score+=20;}else if(v.length<45&&canonical(text).includes(canonical(v)))score+=r.weight;}
 if(profile?.id==='monitor'){const a=numeric(field(p,['Диагональ экрана','Диагональ'])),b=numeric(c.name.replace(/^Монитор\s*/i,''));if(Number.isFinite(a)&&Number.isFinite(b))score-=Math.abs(a-b)*3;}return score;
}

import type {Match, Product} from '../xcom/types.ts';

export type SearchCriteria = {priceMin:string;priceMax:string;quantity:string};
export type RecentSearch = {name:string;url:string;city?:'msk'|'spb';criteria?:SearchCriteria};

export function partitionMatches(matches:Match[]) {
  return {matched:matches.filter(m=>m.level==='matched'),review:matches.filter(m=>m.level==='review')};
}

export type SearchOutcome = {matches:unknown[];failed:number;sourceWarning?:string;nextOffset:number|null;diagnostics?:{searchFailed?:number}};

// Informational warnings (e.g. missing category metadata) do not mean a request failed.
export function hasSearchGaps(data:Pick<SearchOutcome,'failed'|'diagnostics'>) {
  return data.failed>0||(data.diagnostics?.searchFailed??0)>0;
}

export function resultState(data:SearchOutcome) {
  if(data.matches.length) return 'found';
  // Keep continuation reachable even if another catalogue request failed.
  if(data.nextOffset!==null) return 'more';
  return hasSearchGaps(data)?'partial':'empty';
}

// Uniform random choice; a previous illustration is excluded, never a fixed queue.
export function randomMascot(previous:number|null=null,random=Math.random,count=33) {
  if(count<2) return 0;
  const valid=previous!==null&&Number.isInteger(previous)&&previous>=0&&previous<count;
  const n=Math.min(1-Number.EPSILON,Math.max(0,random()));
  const pick=Math.floor(n*(valid?count-1:count));
  return valid&&pick>=previous! ? pick+1 : pick;
}

export function nextMascot() {
  let previous:number|null=null;
  try {const stored=sessionStorage.getItem('xcom-last-mascot');if(stored!==null)previous=Number(stored);}catch{}
  const pick=randomMascot(previous);
  try {sessionStorage.setItem('xcom-last-mascot',String(pick));}catch{}
  return pick;
}

export function criteriaEqual(a:SearchCriteria,b:SearchCriteria) {
  return a.priceMin===b.priceMin&&a.priceMax===b.priceMax&&a.quantity===b.quantity;
}

export function criteriaError(c:SearchCriteria) {
  const min=c.priceMin===''?null:Number(c.priceMin),max=c.priceMax===''?null:Number(c.priceMax),qty=Number(c.quantity);
  if((min!==null&&(!Number.isFinite(min)||min<0))||(max!==null&&(!Number.isFinite(max)||max<0)))return 'Укажите цену от нуля или оставьте поле пустым.';
  if(min!==null&&max!==null&&min>max)return 'Цена «от» не должна быть больше цены «до».';
  if(!Number.isInteger(qty)||qty<1||qty>10000)return 'Укажите количество от 1 до 10 000 штук.';
  return '';
}

export function comparisonKeys(products:Product[],onlyDifferences:boolean) {
  const keys=Array.from(new Set(products.flatMap(p=>Object.keys(p.specs))));
  return onlyDifferences?keys.filter(k=>products.some(p=>(p.specs[k]||'').trim()!==(products[0]?.specs[k]||'').trim())):keys;
}

export function proposalText(match:Match,source:Product,city:string,checkedAt:string) {
  const price=match.product.price===null?'Цена не указана':new Intl.NumberFormat('ru-RU').format(match.product.price)+' ₽';
  const lines=[`Замена для ${source.name}:`,match.product.name,`${price} · ${city}`,match.product.url];
  if(match.differences.length)lines.push('Отличия: '+match.differences.slice(0,4).join('; '));
  if(match.level==='review')lines.push('Требует проверки: '+[...match.missing,...match.reasons].slice(0,3).join('; '));
  lines.push('Наличие проверено: '+new Date(checkedAt).toLocaleString('ru-RU',{timeZone:'Europe/Moscow'}));
  return lines.join('\n');
}

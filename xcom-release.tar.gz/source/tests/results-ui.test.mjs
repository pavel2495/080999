import test from 'node:test';
import assert from 'node:assert/strict';
import {partitionMatches,resultState,randomMascot,criteriaEqual,criteriaError,comparisonKeys,proposalText} from '../lib/ui/results.ts';

test('confirmed and review tabs partition the actual response without duplicates',()=>{
 const items=Array.from({length:30},(_,i)=>({product:{id:String(i)},level:i<2?'matched':'review'}));
 const groups=partitionMatches(items);
 assert.equal(groups.matched.length,2);assert.equal(groups.review.length,28);
 assert.equal(new Set([...groups.matched,...groups.review].map(m=>m.product.id)).size,30);
 assert.ok(groups.matched.every(m=>m.level==='matched'));assert.ok(groups.review.every(m=>m.level==='review'));
});

test('a failed or incomplete zero-result search never becomes a definitive empty result',()=>{
 const base={matches:[],failed:0,nextOffset:null};
 assert.equal(resultState(base),'empty');
 assert.equal(resultState({...base,failed:1}),'partial');
 assert.equal(resultState({...base,diagnostics:{searchFailed:1},sourceWarning:'Часть каталога не ответила'}),'partial');
 assert.equal(resultState({...base,sourceWarning:'Недостаточно технических характеристик',diagnostics:{searchFailed:0}}),'empty');
 assert.equal(resultState({...base,sourceWarning:'Категория не найдена в индексе'}),'empty');
 assert.equal(resultState({...base,nextOffset:100,failed:1}),'more');
 assert.equal(resultState({...base,nextOffset:100}),'more');
 assert.equal(resultState({...base,matches:[{level:'review'}]}),'found');
});

test('random selection can reach every approved duck, skips only the immediate previous duck',()=>{
 assert.deepEqual(new Set(Array.from({length:33},(_,i)=>randomMascot(null,()=>i/33))),new Set(Array.from({length:33},(_,i)=>i)));
 for(let previous=0;previous<33;previous++){
  const picks=Array.from({length:32},(_,i)=>randomMascot(previous,()=>i/32));
  assert.equal(new Set(picks).size,32);assert.ok(!picks.includes(previous));assert.ok(picks.every(i=>i>=0&&i<33));
 }
 assert.equal(randomMascot(null,()=>1),32);
});

test('editing search criteria can be distinguished from the snapshot used for pagination',()=>{
 const applied={priceMin:'10000',priceMax:'50000',quantity:'1'};
 const draft={...applied,priceMax:'70000'};
 assert.ok(!criteriaEqual(draft,applied));assert.equal(applied.priceMax,'50000');
 assert.ok(criteriaEqual({...applied},applied));
 assert.match(criteriaError({...draft,priceMin:'80000'}),/больше/);
 assert.match(criteriaError({...draft,quantity:'0'}),/количество/);
 assert.equal(criteriaError({priceMin:'',priceMax:'',quantity:'1'}),'');
});

test('only-differences comparison keeps missing specifications visible',()=>{
 const products=[{specs:{socket:'AM5',memory:'DDR5',ports:'HDMI'}},{specs:{socket:'AM5',memory:'DDR5'}}];
 assert.deepEqual(comparisonKeys(products,true),['ports']);
 assert.deepEqual(comparisonKeys(products,false),['socket','memory','ports']);
});

test('client proposal includes review qualifications, city, timestamp and direct product link',()=>{
 const m={product:{name:'Замена',price:12000,url:'https://www.xcom-shop.ru/replacement_123.html'},level:'review',differences:['Частота: 144 → 120 Гц'],missing:['Разъёмы'],reasons:[]};
 const text=proposalText(m,{name:'Исходный товар'},'Санкт-Петербург','2026-10-23T12:00:00Z');
 assert.match(text,/Санкт-Петербург/);assert.match(text,/replacement_123/);assert.match(text,/Требует проверки: Разъёмы/);assert.match(text,/Частота: 144 → 120 Гц/);
 assert.doesNotMatch(text,/на складе|осталось|гарантирован/i);
});

// Regression: a completed, budget-limited scan may carry metadata notes without any network failure.
test('a completed zero-result budget scan is empty despite informational metadata warnings',()=>{
 const response={matches:[],checked:46,failed:0,nextOffset:null,coverage:'searched',diagnostics:{searchFailed:0,budgetExcluded:46,categoryLookupFailed:true},sourceWarning:'Категорию не удалось подтвердить в поисковом индексе. Использованы характеристики и категория карточки.'};
 assert.equal(resultState(response),'empty');
 assert.equal(resultState({...response,sourceWarning:'Недостаточно проверенных технических данных для уверенного подбора в этой категории.'}),'empty');
 assert.equal(resultState({...response,failed:1}),'partial');
});

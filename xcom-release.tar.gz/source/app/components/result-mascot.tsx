'use client';
import {useEffect,useRef,useState} from 'react';
import {AlertCircle,ArrowRight,RefreshCw} from 'lucide-react';
import {resultState,hasSearchGaps} from '../../lib/ui/results';
import type {SearchOutcome} from '../../lib/ui/results';

export function MascotArt({src,large=false}:{src:string;large?:boolean}) {
  const ref=useRef<HTMLImageElement>(null),[ready,setReady]=useState(false),[failed,setFailed]=useState(false);
  useEffect(()=>{setReady(!!ref.current?.complete&&!!ref.current?.naturalWidth);setFailed(false);},[src]);
  if(failed)return null;
  return <div className={'mascot-art '+(large?'large ':'')+(ready?'is-ready':'is-loading')} aria-hidden="true"><img ref={ref} src={src} alt="" decoding="async" onLoad={()=>setReady(true)} onError={()=>setFailed(true)}/></div>;
}

export function FoundMascot({mascotId,city}:{mascotId:number|null;city:string}) {
  if(mascotId===null)return null;
  const src=`/mascots/duck-${String((mascotId??0)+1).padStart(2,'0')}.png?v=clean2`;
  return <div className="found-mascot"><MascotArt key={src} src={src}/><div><p>Варианты найдены. Сравните основные параметры и отличия.</p><small>{city} · наличие проверено на XCOM-SHOP</small></div></div>;
}

export function EmptyOutcome({data,hasPrice,onEdit,onReset,onRetry,onMore,loadingMore,conditionsChanged=false}:{data:SearchOutcome;hasPrice:boolean;onEdit:()=>void;onReset:()=>void;onRetry:()=>void;onMore:()=>void;loadingMore:boolean;conditionsChanged?:boolean}) {
  const state=resultState(data),gaps=hasSearchGaps(data);
  const description=state==='more'
    ?'В проверенных карточках подходящих замен пока нет. В каталоге остались следующие товары — поиск можно продолжить с теми же условиями.'
    :gaps
      ?'В проверенных карточках подходящих замен не найдено. Часть данных получить не удалось, поэтому отсутствие вариантов во всём каталоге пока не подтверждено.'
      :hasPrice
        ?'В проверенных карточках не найдено подходящих замен в указанном диапазоне цен. Попробуйте изменить или сбросить цену.'
        :'В проверенных карточках не найдено подходящих замен. Попробуйте изменить условия поиска.';
  return <div className="empty-outcome" role="status"><h3>К сожалению, ничего не нашлось</h3><p>{description}</p><MascotArt src="/mascots/empty-tinkov.png?v=clean2" large/>
    <div className="outcome-actions">{state==='more'&&<button className="primary" onClick={onMore} disabled={loadingMore||conditionsChanged}>{loadingMore?'Проверяем…':'Продолжить поиск'}<ArrowRight size={14}/></button>}<button className={state==='more'?'copy-btn':'primary'} onClick={onEdit} disabled={loadingMore}>Изменить условия</button>{hasPrice&&<button className="copy-btn" onClick={onReset} disabled={loadingMore}>Сбросить цену</button>}</div>
    {(gaps||data.sourceWarning)&&<div className="outcome-caveat"><p>{gaps&&<AlertCircle size={14}/>}<span>{gaps?`${data.failed>0?'Не удалось прочитать карточек: '+data.failed+'. ':''}${(data.diagnostics?.searchFailed??0)>0?'Часть запросов каталога не ответила. ':''}Можно повторить проверку.`:data.sourceWarning}</span></p>{gaps&&<button className="text-btn" onClick={onRetry} disabled={loadingMore||conditionsChanged}><RefreshCw size={13}/>Повторить проверку</button>}</div>}
  </div>;
}

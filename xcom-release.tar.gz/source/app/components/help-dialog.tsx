'use client';
import {useEffect,useRef} from 'react';
import {X} from 'lucide-react';

export function HelpDialog({onClose}:{onClose:()=>void}) {
  const ref=useRef<HTMLDialogElement>(null);
  useEffect(()=>{const el=ref.current;if(el&&!el.open)el.showModal();return()=>{if(el?.open)el.close();};},[]);
  return <dialog ref={ref} className="modal help-dialog" aria-labelledby="help-title" onCancel={onClose} onClick={e=>{if(e.target===ref.current)onClose();}}><div className="modal-head"><h2 id="help-title">Как пользоваться</h2><button className="icon-button" aria-label="Закрыть инструкцию" onClick={onClose}><X size={20}/></button></div><ol className="help-steps"><li><strong>Укажите товар</strong><p>Вставьте ссылку XCOM-SHOP, код, артикул или модель. Если предложено несколько модификаций — выберите нужную.</p></li><li><strong>Выберите условия</strong><p>Москва или Санкт-Петербург, цена от и до. После изменения условий нажмите «Применить».</p></li><li><strong>Посмотрите две группы</strong><p>«Аналоги в наличии» — совпадают основные параметры. «Нужно уточнить» — есть отличия или недостающие сведения, которые нужно проверить. Товары между группами не повторяются.</p></li><li><strong>Сравните и откройте товар</strong><p>Выберите до трёх вариантов, включите «Только отличия» или откройте карточку магазина. Можно скопировать ссылку или короткое предложение клиенту.</p></li></ol><div className="help-note"><p>Наличие относится к выбранному городу на момент проверки. Перед оформлением заказа обновите его. Точное свободное количество не подтверждается.</p><p>Если проверена только часть каталога, нажмите «Проверить больше товаров». Ошибка связи с магазином не означает отсутствие аналогов.</p></div></dialog>;
}

import{imageUrl}from '../../../lib/xcom/catalog';
export async function GET(request:Request){
 let src:string;try{src=imageUrl(new URL(request.url).searchParams.get('src')||'');}catch{return new Response('Недопустимый адрес изображения',{status:400});}
 const variants=[src,src.replace(/_\d+\.(?:webp|jpg|png)(?=$|\?)/i,'')].filter((v,i,a)=>a.indexOf(v)===i);
 for(const url of variants){try{const r=await fetch(url,{redirect:'manual',headers:{Accept:'image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8'},signal:AbortSignal.timeout(18000)});const type=r.headers.get('Content-Type')?.split(';')[0]||'';if(!r.ok||!/^image\/(jpeg|png|webp|gif|avif)$/i.test(type)||Number(r.headers.get('Content-Length')||0)>8000000){await r.body?.cancel();continue;}const reader=r.body?.getReader();if(!reader)continue;const chunks:Uint8Array[]=[];let length=0;while(true){const v=await reader.read();if(v.done)break;length+=v.value.length;if(length>8000000){await reader.cancel();break;}chunks.push(v.value);}if(length>8000000||length===0)continue;const output=new Uint8Array(length);let at=0;for(const c of chunks){output.set(c,at);at+=c.length;}return new Response(output,{headers:{'Content-Type':type,'Cache-Control':'public,max-age=86400','X-Content-Type-Options':'nosniff'}});}catch{}}
 return new Response('Фотография временно недоступна',{status:404,headers:{'Cache-Control':'public,max-age=60'}});
}

import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'XCOM Аналоги — подбор замены',description:'Подбор аналогов по характеристикам и наличию только в XCOM-SHOP.',icons:{icon:'/favicon.svg',apple:'/icon-192.png'},manifest:'/manifest.webmanifest'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="ru" suppressHydrationWarning><body>{children}</body></html>}

import {createServer,type IncomingMessage,type ServerResponse} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {GET as search} from '../app/api/search/route';
import {GET as getAnalogs,POST as postAnalogs} from '../app/api/analogs/route';
import {GET as image} from '../app/api/image/route';

const directory=resolve(fileURLToPath(new URL('../public/',import.meta.url)));
const types:Record<string,string>={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg','.ico':'image/x-icon','.woff2':'font/woff2'};
let active=0;
async function send(res:ServerResponse,response:Response,head=false){
 res.writeHead(response.status,Object.fromEntries(response.headers));
 if(!head&&response.body)res.end(Buffer.from(await response.arrayBuffer()));else res.end();
}
async function handle(req:IncomingMessage,res:ServerResponse){
 const method=req.method||'GET',url=new URL(req.url||'/','http://localhost');
 if(url.pathname==='/healthz'){res.writeHead(200,{'Content-Type':'application/json'});res.end('{"ok":true}');return;}
 if(url.pathname.startsWith('/api/')){
  if(!['GET','POST'].includes(method)){res.writeHead(405);res.end();return;}
  const handler=url.pathname==='/api/search'&&method==='GET'?search:url.pathname==='/api/image'&&method==='GET'?image:url.pathname==='/api/analogs'?(method==='POST'?postAnalogs:getAnalogs):null;
  if(!handler){res.writeHead(404);res.end();return;}
  if(active>=4){await send(res,Response.json({error:'Сервис сейчас проверяет другие товары. Повторите запрос чуть позже.'},{status:429}));return;}
  active++;
  try{
   const chunks:Buffer[]=[];let bytes=0;
   for await(const chunk of req){const b=Buffer.from(chunk);bytes+=b.length;if(bytes>1800000){await send(res,Response.json({error:'Слишком большой запрос.'},{status:413}));return;}chunks.push(b);}
   const request=new Request(url,{method,headers:{'Content-Type':'application/json'},...(method==='POST'?{body:Buffer.concat(chunks).toString('utf8')}:{})});
   await send(res,await handler(request));
  }finally{active--;}
  return;
 }
 if(!['GET','HEAD'].includes(method)){res.writeHead(405);res.end();return;}
 let name:string;try{name=decodeURIComponent(url.pathname);}catch{res.writeHead(400);res.end();return;}
 const file=resolve(directory,'.'+(name==='/'?'/index.html':name));
 if(!file.startsWith(directory+sep)){res.writeHead(404);res.end();return;}
 try{if(!(await stat(file)).isFile())throw new Error();const body=await readFile(file);res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Content-Length':body.length,'X-Content-Type-Options':'nosniff','Cache-Control':file.endsWith('.html')?'no-store':'public,max-age=3600'});res.end(method==='HEAD'?undefined:body);}catch{res.writeHead(404);res.end();}
}
const server=createServer((req,res)=>{handle(req,res).catch(()=>{if(!res.headersSent)res.writeHead(500,{'Content-Type':'application/json'});res.end('{"error":"Ошибка сервера. Повторите запрос позже."}');});});
server.requestTimeout=180000;
server.listen(Number(process.env.PORT||10000),'0.0.0.0',()=>console.log('XCOM Analogs server ready'));

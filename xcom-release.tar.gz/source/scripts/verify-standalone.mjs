import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {once} from 'node:events';
const child=spawn(process.execPath,['standalone-dist/server/index.mjs'],{env:{...process.env,PORT:'10019'},stdio:['ignore','pipe','pipe']});
try{
 await Promise.race([once(child.stdout,'data'),once(child,'exit').then(()=>{throw new Error('Server exited before readiness');}),new Promise((_,reject)=>{const timer=setTimeout(()=>reject(new Error('Server startup timeout')),10000);timer.unref();})]);
 const base='http://127.0.0.1:10019';
 const checks=await Promise.all([
  fetch(base+'/healthz').then(async r=>{assert.equal(r.status,200);assert.equal((await r.json()).ok,true);}),
  fetch(base+'/').then(async r=>{assert.equal(r.status,200);assert.match(await r.text(),/XCOM Аналоги/);}),
  fetch(base+'/mascots/duck-01.png').then(async r=>{assert.equal(r.headers.get('content-type'),'image/png');assert.ok((await r.arrayBuffer()).byteLength>1000);}),
  fetch(base+'/api/search?q=a').then(r=>assert.equal(r.status,400)),
  fetch(base+'/api/image?src=https://example.com/private.png').then(r=>assert.equal(r.status,400)),
  fetch(base+'/.openai/hosting.json').then(r=>assert.equal(r.status,404)),
  fetch(base+'/api/analogs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:'https://example.com/product'})}).then(r=>assert.equal(r.status,400)),
 ]);
 console.log(`Standalone smoke checks passed: ${checks.length}`);
}finally{child.kill('SIGTERM');}

import {build} from 'vite';
import react from '@vitejs/plugin-react';
import {resolve} from 'node:path';
const root=process.cwd();
await build({configFile:false,root:resolve(root,'standalone/client'),publicDir:resolve(root,'public'),plugins:[react()],build:{outDir:resolve(root,'standalone-dist/public'),emptyOutDir:true}});
await build({configFile:false,build:{ssr:resolve(root,'standalone/server.ts'),outDir:resolve(root,'standalone-dist/server'),emptyOutDir:true,rollupOptions:{output:{entryFileNames:'index.mjs'}}}});

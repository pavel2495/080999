import { AsyncLocalStorage } from "node:async_hooks";
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
//#region lib/xcom/request-budget.ts
var deadlines = new AsyncLocalStorage();
function withRequestBudget(milliseconds, run) {
	return deadlines.run(Date.now() + milliseconds, run);
}
function requestDeadline() {
	return deadlines.getStore() ?? Infinity;
}
function remainingRequestTime() {
	return Math.max(0, requestDeadline() - Date.now());
}
//#endregion
//#region lib/xcom/normalize.ts
function clean(s) {
	return s.replace(/<!--[\s\S]*?-->/g, "").replace(/<[^>]*>/g, " ").replace(/&nbsp;|&#160;/g, " ").replace(/&quot;/g, "\"").replace(/&#039;|&apos;/g, "'").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/\s+/g, " ").trim();
}
function normalize(s) {
	return clean(s).toLowerCase().replace(/ё/g, "е").replace(/,/g, ".").replace(/[″”"]/g, "").replace(/\s+/g, " ").trim();
}
function field(p, keys) {
	for (const k of keys) {
		const key = Object.keys(p.specs).find((x) => normalize(x) === normalize(k));
		if (key && p.specs[key].trim()) return p.specs[key];
	}
	return "";
}
function numeric(s) {
	return Number(normalize(s).match(/-?\d+(?:\.\d+)?/)?.[0] || NaN);
}
function capacity(s) {
	let n = numeric(s);
	if (/тб|\btb\b/.test(normalize(s))) n *= 1e3;
	if (/мб|\bmb\b/.test(normalize(s))) n /= 1024;
	return n;
}
function canonical(s) {
	const n = normalize(s);
	if (/^(?:монохромная|монохромный|черно-белая|черно-белый|ч\/б)$/.test(n)) return "mono";
	if (/^(?:цветная|цветной)$/.test(n)) return "color";
	if (/^(?:да|есть|поддерживается)$/.test(n)) return "yes";
	if (/^(?:нет|не поддерживается|отсутствует)$/.test(n)) return "no";
	return n.replace(/(\d)\s*[х×]\s*(\d)/g, "$1x$2").replace(/pci[ -]?(?:express|e)/g, "pcie").replace(/sata\s*(?:iii|3(?:\.0)?)/g, "sata3").replace(/[мm]\.?2/g, "m2").replace(/micro[- ]?atx|m-atx/g, "matx").replace(/mini[- ]?itx/g, "mitx").replace(/socket|сокет/g, "").replace(/[^a-zа-я0-9+]/g, "");
}
function ddr(s) {
	return normalize(s).match(/(?:lp)?ddr\s*\d/)?.[0].replace(/\s/g, "") || canonical(s);
}
function resolution(s) {
	return normalize(s).replace(/(\d)\s*[xх×*]\s*(\d)/g, "$1x$2").match(/\d{3,5}x\d{3,5}/)?.[0] || canonical(s);
}
function tokens(s) {
	return clean(s).split(/[,;]|\s+\/\s+/).map(canonical).filter(Boolean);
}
function ports(s) {
	const n = normalize(s), out = [];
	if (/hdmi/.test(n)) out.push("hdmi");
	if (/display\s*port|displayport|\bdp\b/.test(n)) out.push("displayport");
	if (/d[- ]?sub|vga/.test(n)) out.push("vga");
	if (/dvi/.test(n)) out.push("dvi");
	if (/usb\s*(?:type[- ]?)?[- ]?c\b|type-c/.test(n)) out.push("usb-c");
	return out.length ? out : tokens(s);
}
function gpuChip(text) {
	const m = normalize(text).match(/\b(rtx|gtx|rx)\s*[- ]?(\d{3,4})\s*(ti\s*super|super|ti|xtx|xt|gre)?\b|\barc\s*([ab]\d{3})\b/i);
	return m ? m[4] ? "arc " + m[4] : m[1] + " " + m[2] + (m[3] ? " " + m[3].replace(/\s+/g, " ") : "") : "";
}
function inputQuery(q) {
	const t = q.normalize("NFKC").trim().replace(/\s+/g, " ");
	if (/^[\w.+/-]*\d[\w.+/-]*$/.test(t)) return t;
	return t.replace(/\b(?:videocard|gpu)\b/gi, "видеокарта").replace(/\b(?:motherboard|mainboard)\b/gi, "материнская плата").replace(/\b(?:monitor)\b/gi, "монитор").replace(/\b(?:laptop|notebook)\b/gi, "ноутбук").replace(/\b(?:printer)\b/gi, "принтер").replace(/\b(?:mfp)\b/gi, "МФУ").replace(/\b(?:router)\b/gi, "маршрутизатор").replace(/видюха|видеокарточка/gi, "видеокарта").replace(/материнка/gi, "материнская плата").replace(/оперативка/gi, "оперативная память").replace(/ж[её]сткий/gi, "жесткий");
}
function editDistance(a, b) {
	let row = Array.from({ length: b.length + 1 }, (_, i) => i);
	for (let i = 1; i <= a.length; i++) {
		const next = [i];
		for (let j = 1; j <= b.length; j++) next[j] = Math.min(next[j - 1] + 1, row[j] + 1, row[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
		row = next;
	}
	return row[b.length];
}
function categoryTypo(query) {
	const first = query.split(" ")[0];
	if (!/^[а-яё]{5,}$/i.test(first)) return query;
	const words = [
		"монитор",
		"ноутбук",
		"компьютер",
		"процессор",
		"принтер",
		"сканер",
		"смартфон",
		"планшет",
		"телевизор",
		"проектор",
		"видеокарта",
		"клавиатура",
		"коммутатор",
		"маршрутизатор",
		"картридж",
		"гарнитура",
		"аккумулятор",
		"кронштейн"
	];
	const n = normalize(first);
	if (words.includes(n)) return query;
	const ranked = words.map((word) => ({
		word,
		d: editDistance(n, word)
	})).sort((a, b) => a.d - b.d);
	return ranked[0].d <= 2 && ranked[0].d < ranked[1].d ? ranked[0].word + query.slice(first.length) : query;
}
//#endregion
//#region lib/xcom/profiles.ts
var r = (label, keys, kind = "exact", priority = "critical", extra = {}) => ({
	label,
	keys,
	kind,
	priority,
	weight: priority === "critical" ? 12 : priority === "important" ? 6 : 2,
	...extra
});
var imp = (label, keys, kind = "exact", extra = {}) => r(label, keys, kind, "important", extra);
var opt = (label, keys, kind = "exact") => r(label, keys, kind, "secondary");
var diag = (t) => r("Диагональ", ["Диагональ экрана", "Диагональ"], "diagonal", "critical", { tolerance: t });
var res = r("Разрешение", [
	"Максимальное разрешение",
	"Разрешение экрана",
	"Разрешение"
], "resolution");
var refresh = imp("Частота обновления", [
	"Частота обновления экрана",
	"Частота обновления",
	"Максимальная частота обновления"
], "minimum", {
	floor: .8,
	required: true
});
var matrix$1 = imp("Тип матрицы", ["Тип матрицы"], "matrix");
var iface = r("Интерфейс", [
	"Интерфейс подключения",
	"Интерфейс подключения к ПК",
	"Интерфейс"
]);
var form = r("Форм-фактор", ["Форм-фактор"], "form");
var vol = imp("Объём", [
	"Объем накопителя",
	"Объем",
	"Емкость"
], "capacity", {
	required: true,
	floor: .5
});
var computer = [
	r("Класс процессора", ["Модель процессора", "Процессор"], "processor"),
	imp("Ядра", ["Количество ядер", "Количество ядер на один процессор"], "minimum"),
	imp("Оперативная память", [
		"Объем оперативной памяти",
		"Оперативная память",
		"Предустановленный объём памяти"
	], "capacity", {
		required: true,
		floor: .5
	}),
	imp("Накопитель", ["Объем твердотельных накопителей (SSD)", "Объем накопителя"], "capacity", { floor: .5 }),
	imp("Графика", [
		"Модель видеокарты",
		"Модель интегрированной видеокарты",
		"Графический процессор"
	], "processor"),
	imp("ОС", ["Операционная система", "ОС"], "os"),
	opt("Разъёмы", ["Видеоразъемы", "Интерфейсы подключения"], "ports")
];
var print = [
	r("Технология печати", ["Технология печати"]),
	r("Цветность", ["Тип печати", "Цветность печати"]),
	r("Формат бумаги", ["Максимальный формат печати", "Максимальный формат бумаги"]),
	imp("Скорость печати", [
		"Скорость печати А4 ч/б",
		"Скорость печати А4 цветная",
		"Скорость печати"
	], "minimum", { floor: .6 }),
	imp("Дуплекс", ["Двусторонняя печать (дуплекс)", "Автоматическая двусторонняя печать"]),
	imp("Интерфейсы", ["Интерфейс", "Интерфейсы"], "set"),
	imp("Автоподатчик", ["Автоподатчик"]),
	imp("Нагрузка", ["Нагрузка в месяц (средняя)"], "minimum", { floor: .5 })
];
var wireless = [
	imp("Диапазоны", [
		"Частотный диапазон",
		"Диапазон частот",
		"Диапазоны Wi-Fi"
	], "set", { required: true }),
	imp("Wi-Fi", [
		"Стандарт Wi-Fi",
		"Стандарты Wi-Fi",
		"Беспроводные стандарты"
	], "set"),
	imp("Скорость портов", [
		"Скорость Ethernet портов",
		"Сетевые интерфейсы",
		"Скорость WAN портов"
	], "speed"),
	imp("Количество портов", [
		"Кол-во Ethernet портов",
		"Количество LAN портов",
		"Общее количество портов"
	], "minimum"),
	r("PoE", ["Стандарт PoE"], "set", "critical"),
	opt("Питание", ["Электропитание", "Питание"])
];
var PROFILES = [
	{
		id: "gpu",
		label: "Видеокарта",
		name: /^видеокарта(?=\s|$|[,(])/,
		path: /\/videokarty\//,
		rules: [
			r("Графический процессор", ["Графический процессор", "Модель графического процессора"], "gpu"),
			r("Видеопамять", ["Объем видеопамяти", "Объем памяти"], "capacity"),
			r("Тип памяти", ["Тип памяти"]),
			r("Видеовыходы", ["Разъемы", "Видеоразъемы"], "ports"),
			imp("Шина памяти", ["Шина видеопамяти"], "minimum"),
			imp("Длина видеокарты", ["Длина видеокарты"]),
			imp("Слоты корпуса", ["Количество занимаемых слотов расширения"]),
			imp("Питание", ["Разъемы дополнительного питания"]),
			imp("Блок питания", ["Рекомендуемый блок питания"]),
			opt("Интерфейс", ["Интерфейс", "Версия интерфейса"]),
			opt("Охлаждение", ["Тип охлаждения"]),
			opt("Турбочастота", ["Турбочастота"], "minimum")
		]
	},
	{
		id: "motherboard",
		label: "Материнская плата",
		name: /^материнская плата/,
		path: /\/materinskie_platy\//,
		rules: [
			r("Сокет", ["Сокет", "Socket"]),
			r("Тип памяти", ["Тип поддерживаемой памяти", "Тип памяти"], "ddr"),
			imp("Форм-фактор", ["Форм-фактор"], "form", { required: true }),
			imp("Чипсет", ["Чипсет"]),
			imp("Слоты памяти", ["Количество слотов памяти"], "minimum"),
			imp("Разъёмы M.2", ["Количество разъемов M.2"], "minimum"),
			imp("Питание CPU", ["Разъем питания процессора"]),
			opt("Wi-Fi", ["Стандарт Wi-Fi"]),
			opt("PCI Express", ["Версия PCI Express"])
		],
		review: "Поддержка конкретного процессора и версии BIOS"
	},
	{
		id: "laptop",
		label: "Ноутбук",
		name: /^ноутбук(?=\s|$|[,(])/,
		path: /\/noytbyki\/$/,
		rules: [
			...computer,
			diag(1),
			res,
			imp("Тип памяти", ["Тип оперативной памяти", "Тип памяти"], "ddr"),
			imp("Сенсорный экран", ["Сенсорный экран"]),
			opt("Масса", ["Вес"], "minimum")
		]
	},
	{
		id: "computer",
		label: "Компьютер",
		name: /^(?:компьютер|мини[- ]?пк|моноблок|неттоп)(?=\s|$|[,(])/,
		path: /\/(?:kompyutery|nettops|monobloki|mini_pk)\/$/,
		rules: [
			...computer,
			imp("Корпус", ["Формат корпуса", "Форм-фактор"], "form"),
			imp("Тип компьютера", ["Тип компьютера"], "set")
		]
	},
	{
		id: "server",
		label: "Сервер",
		name: /^сервер(?=\s|$|[,(])/,
		path: /\/servery\/$/,
		rules: [
			...computer,
			r("Форм-фактор", ["Форм-фактор", "Исполнение"], "form"),
			imp("Высота в стойке", ["Высота в стойке"]),
			imp("Сокеты", ["Количество сокетов"], "minimum"),
			imp("Дисковые отсеки", ["Количество дисковых отсеков"], "minimum"),
			r("Формат дисков", ["Форм-фактор накопителей"], "set"),
			imp("Сеть", ["Установленные сетевые интерфейсы"], "set")
		],
		review: "Совместимость CPU, памяти, корзин, контроллеров и блоков питания"
	},
	{
		id: "ssd",
		label: "SSD",
		name: /^(?:ssd(?=\s|$|[,(])|(?:твердотельный )?накопитель ssd(?=\s|$|[,(])|твердотельный накопитель)/,
		path: /\/ssd_nakopiteli\/$/,
		rules: [
			form,
			iface,
			vol,
			imp("Протокол", ["Протокол", "Поддержка NVMe"]),
			imp("Чтение", [
				"Максимальная скорость последовательного чтения",
				"Скорость чтения",
				"Скорость чтения до"
			], "minimum", { floor: .5 }),
			imp("Запись", [
				"Максимальная скорость последовательной записи",
				"Скорость записи",
				"Скорость записи до"
			], "minimum", { floor: .5 }),
			opt("Ресурс", [
				"Ресурс TBW",
				"TBW",
				"Максимальный ресурс записи (TBW)"
			], "minimum"),
			opt("Тип памяти", ["Тип памяти"]),
			opt("Назначение", ["Назначение"], "set")
		]
	},
	{
		id: "hdd",
		label: "Жесткий диск",
		name: /^(?:жесткий диск|hdd(?=\s|$|[,(]))/,
		path: /\/zhestkie_diski\/$/,
		rules: [
			form,
			iface,
			vol,
			imp("Назначение", ["Назначение"], "set"),
			imp("Обороты", ["Скорость вращения шпинделя"], "minimum"),
			opt("Запись", ["Метод записи", "Технология записи"])
		]
	},
	{
		id: "external-drive",
		label: "Внешний накопитель",
		name: /^(?:внешний (?:накопитель|жесткий диск|диск|ssd)|портативный накопитель)/,
		path: /\/vneshnie_(?:zhestkie_diski|ssd_nakopiteli)\/$/,
		rules: [
			imp("Вид накопителя", ["Вид накопителя", "Тип накопителя"]),
			r("Интерфейс", ["Интерфейс подключения к ПК", "Интерфейс подключения"], "set"),
			vol,
			opt("Разъём", ["Разъемы на устройстве"]),
			opt("Защита", ["Защита от внешнего воздействия"])
		]
	},
	{
		id: "memory-card",
		label: "Карта памяти",
		name: /^карта памяти(?=\s|$|[,(])/,
		path: /\/(?:karty_pamyati|flash_karty)\/$/,
		rules: [
			r("Формат", [
				"Тип карты памяти",
				"Тип карты",
				"Тип",
				"Формат карты"
			]),
			vol,
			imp("Класс скорости", [
				"Класс скорости",
				"Класс скорости UHS",
				"Класс"
			], "set"),
			imp("Чтение", ["Скорость чтения", "Максимальная скорость чтения"], "minimum"),
			imp("Запись", ["Скорость записи", "Максимальная скорость записи"], "minimum")
		]
	},
	{
		id: "nas",
		label: "Сетевое хранилище",
		name: /^(?:сетевое хранилище|система хранения|схд(?=\s|$|[,(]))/,
		path: /\/sistemy_hraneniya_dannyh_shd\/$/,
		rules: [
			r("Тип накопителей", ["Тип накопителей"], "set"),
			r("Формат дисков", ["Форм-фактор накопителей"], "set"),
			imp("Отсеки", ["Количество отсеков для накопителей в головной полке", "Количество отсеков"], "minimum", { required: true }),
			r("Протоколы", ["Протоколы доступа"], "set"),
			imp("RAID", ["Уровни RAID"], "set"),
			opt("Исполнение", ["Исполнение"])
		],
		review: "Совместимость накопителей, лицензий и контроллеров"
	},
	{
		id: "ram",
		label: "Оперативная память",
		name: /^(?:оперативная память|память (?:ddr|dimm)|модуль памяти)/,
		path: /\/operativnaya_pamyat\/$/,
		rules: [
			r("Тип памяти", ["Тип памяти"], "ddr"),
			form,
			r("ECC", ["ECC", "Поддержка ECC"]),
			r("Registered", ["Registered", "Буферизованная (Registered)"]),
			r("Объём модуля", ["Объем одного модуля", "Объем памяти"], "capacity"),
			imp("Частота", ["Тактовая частота", "Частота"], "minimum"),
			imp("Модулей в комплекте", ["Количество модулей в комплекте"], "minimum")
		]
	},
	{
		id: "cpu",
		label: "Процессор",
		name: /^процессор(?=\s|$|[,(])/,
		path: /\/protsessory\/$/,
		rules: [
			r("Сокет", ["Сокет", "Socket"]),
			r("Класс процессора", [
				"Модель",
				"Модель процессора",
				"Семейство процессора"
			], "processor"),
			imp("Ядра", ["Количество ядер"], "minimum", { required: true }),
			imp("Тепловыделение", ["TDP", "Тепловыделение"], "minimum"),
			opt("Встроенная графика", ["Графическое ядро", "Встроенная графика"])
		],
		review: "Поддержка процессора платой, BIOS и системой охлаждения"
	},
	{
		id: "monitor",
		label: "Монитор",
		name: /^монитор(?=\s|$|[,(])/,
		path: /\/monitory\/$/,
		rules: [
			diag(.5),
			res,
			r("Видеовыходы", [
				"Видеоразъемы",
				"Интерфейсы подключения",
				"Разъемы",
				"Видеоинтерфейсы"
			], "ports"),
			refresh,
			matrix$1,
			opt("Изогнутый", ["Изогнутый"]),
			opt("Яркость", ["Яркость"], "minimum")
		]
	},
	{
		id: "tv",
		label: "Телевизор",
		name: /^телевизор(?=\s|$|[,(])/,
		path: /\/televizory\/$/,
		rules: [
			diag(5),
			res,
			refresh,
			matrix$1,
			imp("Smart TV", ["Поддержка Smart TV"]),
			imp("Интерфейсы", ["Интерфейсы подключения"], "ports"),
			imp("VESA", ["Крепление VESA"]),
			opt("HDR", ["Поддержка HDR"])
		]
	},
	{
		id: "projector",
		label: "Проектор",
		name: /^проектор(?=\s|$|[,(])/,
		path: /\/proektory\/$/,
		rules: [
			res,
			imp("Технология", ["Технология"]),
			imp("Яркость", ["Яркость"], "minimum", {
				required: true,
				floor: .7
			}),
			imp("Интерфейсы", ["Интерфейс", "Интерфейсы"], "ports"),
			imp("Проекционное отношение", ["Проекционное отношение"]),
			opt("Зум", ["Зум оптический"], "minimum")
		],
		review: "Проекционное расстояние, размер изображения и крепление"
	},
	{
		id: "mfp",
		label: "МФУ",
		name: /^мфу(?=\s|$|[,(])/,
		path: /\/mfy_i_kopiry\/$/,
		rules: [
			...print,
			imp("Сканер", ["Тип сканера"]),
			imp("Скорость сканирования", ["Скорость сканирования A4"], "minimum")
		],
		review: "Совместимость расходных материалов проверяется отдельно"
	},
	{
		id: "printer",
		label: "Принтер",
		name: /^принтер(?=\s|$|[,(])/,
		path: /\/printery\/$/,
		rules: print,
		review: "Совместимость расходных материалов проверяется отдельно"
	},
	{
		id: "plotter",
		label: "Плоттер",
		name: /^плоттер(?=\s|$|[,(])/,
		path: /\/plottery\/$/,
		rules: [...print, imp("Ширина печати", ["Максимальная ширина печати"], "minimum")],
		review: "Расходники и работа с рулонными материалами"
	},
	{
		id: "scanner",
		label: "Сканер",
		name: /^сканер(?=\s|$|[,(])/,
		path: /\/skanery\/$/,
		rules: [
			r("Тип сканирования", ["Тип сканирования"]),
			r("Формат", ["Максимальный формат сканирования", "Максимальный формат"]),
			imp("Разрешение", ["Разрешение сканирования"], "resolution"),
			imp("Технология", ["Технология сканирования"]),
			imp("Автоподатчик", ["Автоподатчик"]),
			imp("Интерфейс USB", ["Интерфейс USB"])
		]
	},
	{
		id: "cartridge",
		label: "Картридж",
		name: /^(?:картридж|тонер[- ]картридж)(?=\s|$|[,(])/,
		path: /\/kartridzhi\/$/,
		rules: [
			r("Совместимые принтеры", ["Совместимость с моделями", "Совместимость"], "set"),
			r("Цвет", ["Цвет печати", "Цвет"]),
			r("Оригинальность", ["Оригинальность"]),
			imp("Ресурс", ["Ресурс", "Ресурс печати"], "minimum", { floor: .5 })
		]
	},
	{
		id: "toner",
		label: "Тонер",
		name: /^тонер(?=\s|$|[,(])/,
		rules: [
			r("Совместимые принтеры", ["Совместимость с моделями", "Совместимость"], "set"),
			r("Цвет", ["Цвет печати", "Цвет"]),
			r("Тип", ["Тип"]),
			imp("Масса", ["Масса", "Вес"], "minimum")
		]
	},
	{
		id: "ink",
		label: "Чернила",
		name: /^чернила(?=\s|$|[,(])/,
		rules: [
			r("Совместимые принтеры", ["Совместимость с моделями", "Совместимость"], "set"),
			r("Цвет", ["Цвет печати", "Цвет"]),
			r("Тип чернил", ["Тип чернил", "Тип"]),
			imp("Объём", ["Объем"], "minimum")
		]
	},
	{
		id: "router",
		label: "Маршрутизатор",
		name: /^(?:роутер|маршрутизатор)(?=\s|$|[,(])/,
		path: /\/marshrytizatory\/$/,
		rules: [
			imp("Скорость сети", [
				"Сетевые интерфейсы",
				"Скорость WAN портов",
				"Скорость WAN"
			], "speed", { required: true }),
			imp("Порты", ["Общее количество портов", "Количество LAN портов"], "minimum"),
			imp("WAN", ["Количество WAN портов"], "minimum"),
			imp("Маршрутизация", ["Маршрутизация"], "set"),
			...wireless
		],
		review: "Режимы маршрутизации, функции и лицензии"
	},
	{
		id: "switch",
		label: "Коммутатор",
		name: /^коммутатор(?=\s|$|[,(])/,
		path: /\/ethernet_kommytatory\/$/,
		rules: [
			r("Управление", [
				"Тип коммутатора",
				"Управляемый",
				"Тип управления",
				"Управление"
			]),
			r("PoE", ["Поддержка PoE", "PoE"]),
			imp("Порты", ["Кол-во основных портов", "Количество портов"], "minimum", {
				required: true,
				floor: .6
			}),
			r("Тип портов", ["Скорость и тип основных портов"], "connector"),
			imp("Скорость портов", ["Скорость и тип основных портов"], "speed"),
			imp("Пропускная способность", ["Пропускная способность"], "speed")
		],
		review: "VLAN, PoE-бюджет, SFP и требуемые сетевые функции"
	},
	{
		id: "access-point",
		label: "Точка доступа",
		name: /^точка доступа(?=\s|$|[,(])/,
		path: /\/wi-fi_tochki_dostypa\/$/,
		rules: [
			r("Режим", ["Режим работы"], "set"),
			...wireless,
			imp("Крепление", ["Форм-фактор"])
		],
		review: "Совместимость с контроллером и PoE-оборудованием"
	},
	{
		id: "network-adapter",
		label: "Сетевой адаптер",
		name: /^(?:сетевая карта|сетевой адаптер|wi-fi адаптер)/,
		path: /\/(?:ethernet_setevye_adaptery|wi-fi_adaptery)\/$/,
		rules: [
			r("Подключение", ["Интерфейс подключения", "Интерфейс"]),
			r("Порты", ["Количество портов"], "connector"),
			imp("Скорость", ["Тип сетевой карты", "Скорость передачи данных"], "speed"),
			...wireless
		]
	},
	{
		id: "ups",
		label: "Источник бесперебойного питания",
		name: /^(?:ибп(?=\s|$|[,(])|источник бесперебойного питания)/,
		path: /\/istochniki_bespereboynogo_pitaniya_ibp\/$/,
		rules: [
			r("Фазы", ["Количество фаз"]),
			imp("Топология", ["Топология ИБП"]),
			imp("Мощность, Вт", ["Эффективная выходная мощность"], "minimum", {
				required: true,
				floor: .7
			}),
			imp("Мощность, ВА", ["Полная выходная мощность"], "minimum", {
				required: true,
				floor: .7
			}),
			r("Батарея", ["Напряжение"]),
			imp("Корпус", ["Форм-фактор корпуса"]),
			imp("Внешние батареи", ["Возможно подключение внешних батарей"]),
			imp("Батарея в комплекте", ["Батареи входят в комплектацию"])
		],
		review: "Выходные розетки, автономность и подключаемая нагрузка"
	},
	{
		id: "battery",
		label: "Аккумулятор",
		name: /^(?:батарея|аккумулятор)(?=\s|$|[,(])/,
		path: /\/akkymylyatornye_batarei\/$/,
		rules: [
			r("Напряжение", ["Напряжение"]),
			r("Клеммы", ["Тип присоединения", "Тип клемм"]),
			r("Габариты", [
				"Габаритный размер",
				"Габариты",
				"Размеры"
			]),
			imp("Ёмкость", ["Ёмкость", "Емкость"], "minimum", {
				required: true,
				floor: .8
			})
		],
		review: "Габариты, полярность, клеммы и совместимость с устройством"
	},
	{
		id: "psu",
		label: "Блок питания",
		name: /^блок питания(?=\s|$|[,(])/,
		path: /\/bloki_pitaniya_dlya_pk\/$/,
		rules: [
			form,
			imp("Мощность", ["Мощность"], "minimum", {
				required: true,
				floor: .8
			}),
			r("Питание платы", ["Питание материнской платы"]),
			r("Питание CPU", ["Разъем для питания процессора (CPU)"], "connector"),
			r("Питание GPU", ["Разъем для питания видеокарты (PCI-E)"], "connector"),
			imp("Глубина", ["Глубина блока питания"]),
			opt("Кабели", ["Отстёгивающиеся кабели"])
		],
		review: "Количество и тип разъёмов питания, габариты корпуса"
	},
	{
		id: "keyboard",
		label: "Клавиатура",
		name: /^(?:(?:мембранная|механическая|беспроводная|проводная) )?клавиатура(?=\s|$|[,(])/,
		path: /\/klaviatyry\/$/,
		rules: [
			r("Подключение", ["Тип подключения", "Тип соединения"]),
			r("Интерфейс", ["Интерфейс подключения", "Интерфейс"], "set"),
			r("Раскладка", ["Раскладка клавиатуры"], "set"),
			imp("Механизм", ["Тип клавиатуры"]),
			imp("Цифровой блок", ["Цифровой блок"]),
			opt("Подсветка", ["Подсветка клавиш"])
		]
	},
	{
		id: "mouse",
		label: "Мышь",
		name: /^(?:(?:оптическая|светодиодная|беспроводная|проводная) ){0,3}мышь(?=\s|$|[,(])/,
		path: /\/myshi\/$/,
		rules: [
			r("Подключение", ["Тип соединения", "Тип подключения"]),
			r("Интерфейс", ["Интерфейс подключения", "Интерфейс"], "set"),
			imp("Сенсор", ["Тип мыши"]),
			imp("Разрешение сенсора", ["Разрешение сенсора"], "minimum"),
			imp("Кнопки", ["Количество кнопок мыши"], "minimum"),
			opt("Питание", ["Тип питания"])
		]
	},
	{
		id: "headset",
		label: "Гарнитура",
		name: /^(?:(?:беспроводная|проводная|игровая) )?(?:гарнитура|моногарнитура|наушники)(?=\s|$|[,(])/,
		path: /\/(?:portativnye_nayshniki_i_garnityry|kompyuternye_garnityry)\/$/,
		rules: [
			r("Тип", ["Тип"]),
			r("Подключение", ["Способ передачи данных", "Интерфейс подключения"], "set"),
			imp("Конструкция", ["Тип конструкции"]),
			imp("Микрофон", ["Микрофон", "Особенности"]),
			opt("Крепление", ["Метод крепления"])
		]
	},
	{
		id: "camera",
		label: "Веб-камера",
		name: /^(?:веб[- ]камера|конференц[- ]камера)/,
		path: /\/veb-kamery\/$/,
		rules: [
			r("Подключение", ["Тип подключения"]),
			r("Интерфейс", ["Интерфейс"], "connector"),
			imp("Разрешение видео", ["Разрешение (видео)", "Максимальное разрешение видео"], "resolution", { required: true }),
			imp("Кадры в секунду", ["Максимальная частота кадров"], "minimum", { floor: .8 }),
			imp("Микрофон", ["Микрофон"]),
			imp("Угол обзора", ["Угол обзора"], "minimum")
		]
	},
	{
		id: "speaker",
		label: "Акустическая система",
		name: /^(?:акустическая система|колонки)(?=\s|$|[,(])/,
		path: /\/akysticheskie_sistemy\/$/,
		rules: [
			r("Тип", ["Тип"]),
			r("Подключение", ["Интерфейсы", "Интерфейс"], "set"),
			imp("Мощность", ["Мощность"], "minimum", {
				required: true,
				floor: .6
			}),
			imp("Динамики", ["Количество динамиков"], "minimum"),
			opt("Сопротивление", ["Сопротивление"])
		]
	},
	{
		id: "smartphone",
		label: "Смартфон",
		name: /^смартфон(?=\s|$|[,(])/,
		path: /\/smartfony\/$/,
		rules: [
			...computer,
			diag(.6),
			res,
			r("ОС", ["Операционная система"], "os"),
			imp("Встроенная память", ["Встроенная память"], "capacity", {
				required: true,
				floor: .5
			}),
			imp("Связь", ["Стандарт связи"], "set"),
			imp("NFC", ["NFC"]),
			imp("Защита", ["Степень защиты"])
		]
	},
	{
		id: "tablet",
		label: "Планшет",
		name: /^планшет(?=\s|$|[,(])/,
		path: /\/planshety\/$/,
		rules: [
			...computer,
			diag(1.5),
			res,
			r("ОС", ["Операционная система"], "os"),
			imp("Встроенная память", ["Встроенная память"], "capacity", {
				required: true,
				floor: .5
			}),
			imp("Связь", ["Стандарт связи"], "set"),
			imp("SIM", ["Слот для sim-карты"]),
			imp("Защита", ["Степень защиты"])
		]
	},
	{
		id: "adapter",
		label: "Переходник",
		name: /^(?:переходник|адаптер (?:hdmi|displayport|usb|vga))(?=\s|$|[,(])/,
		rules: [
			r("Разъёмы", ["Разъемы", "Тип интерфейса Source"], "connector"),
			r("Вид разъёмов", ["Вид разъемов"]),
			r("Направление", ["Поток сигнала"]),
			imp("Разрешение", ["Максимально поддерживаемое разрешение"], "resolution"),
			imp("Длина", ["Длина кабеля"], "minimum", { floor: .8 })
		]
	},
	{
		id: "cable",
		label: "Кабель",
		name: /^(?:(?:активный|оптический|пассивный|соединительный|сетевой) ){0,3}кабель(?=\s|$|[,(])|^патч[- ]?корд/,
		rules: [
			r("Разъём источника", ["Тип интерфейса Source", "Разъемы"], "connector"),
			r("Разъём приёмника", ["Тип интерфейса Display"], "connector"),
			imp("Длина", ["Длина кабеля"], "minimum", {
				required: true,
				floor: .8
			}),
			r("Пропускная способность", ["Пропускная способность"], "speed"),
			imp("Категория кабеля", ["Категория кабеля", "Категория"]),
			opt("Сигнал", ["Формат передаваемого сигнала"])
		]
	},
	{
		id: "mount",
		label: "Кронштейн",
		name: /^(?:кронштейн|крепление|стойка для монитора)/,
		path: /\/krepleniya_podstavki_dlya_monitorov\/$/,
		rules: [
			r("Крепление", ["Тип"]),
			r("VESA", ["Размер VESA", "Крепление VESA"], "set"),
			imp("Нагрузка", ["Максимальный вес устанавливаемого монитора, ТВ"], "minimum", {
				required: true,
				floor: .8
			}),
			imp("Экранов", ["Количество устанавливаемых мониторов или ТВ"], "minimum"),
			imp("Диагональ", ["Максимальный размер диагонали"], "minimum"),
			opt("Регулировка", ["Регулировка по высоте"])
		],
		review: "VESA, масса, диапазон диагоналей и место крепления"
	}
];
function profileFor(p) {
	const n = normalize(p.name);
	if (/^копировальный аппарат/.test(n)) return void 0;
	const byName = PROFILES.find((x) => x.name.test(n));
	const byPath = p.category ? PROFILES.find((x) => x.path?.test(p.category)) : void 0;
	if (byPath?.id === "external-drive" && byName && ["ssd", "hdd"].includes(byName.id)) return byPath;
	return byName || byPath;
}
function family(p) {
	if (/^копировальный аппарат/.test(normalize(p.name))) return "copier";
	return profileFor({
		name: p.name,
		category: p.category || ""
	})?.id || "category:" + (p.category || normalize(p.name).split(" ").slice(0, 2).join(" "));
}
function rulesFor(p) {
	const profile = profileFor(p);
	if (profile) {
		const result = /* @__PURE__ */ new Map();
		for (const rule of profile.rules) {
			const existing = result.get(rule.label);
			if (!existing || rule.weight >= existing.weight) result.set(rule.label, rule);
		}
		return [...result.values()];
	}
	return Object.keys(p.specs).filter((k) => !/(?:цвет|масса|вес|габарит|размер|гаранти|комплект|реестр|артикул|модель)/i.test(k)).slice(0, 18).map((k) => r(k, [k], /(?:интерфейс|совместим|разъ[её]м|напряжени|тип|назначение|формат|протокол|полярност|крепление)/i.test(k) ? "set" : "exact", /(?:совместим|разъ[её]м|напряжени|полярност|тип|формат)/i.test(k) ? "critical" : "important"));
}
//#endregion
//#region lib/xcom/matching.ts
function sameProduct(a, b) {
	return a.id === b.id || a.url === b.url || !!(a.brand && b.brand && canonical(a.brand) === canonical(b.brand) && normalize(a.name) === normalize(b.name)) || !!(a.brand && b.brand && canonical(a.brand) === canonical(b.brand) && a.article && b.article && normalize(a.article) === normalize(b.article));
}
function priceRange(min, max) {
	const parse = (s) => s === null || s.trim() === "" ? null : Number(s);
	const r = {
		min: parse(min),
		max: parse(max)
	};
	if (Object.values(r).some((v) => v !== null && (!Number.isFinite(v) || v < 0 || v > 1e10)) || r.min !== null && r.max !== null && r.min > r.max) throw new Error("Укажите корректную цену «от — до» в рублях.");
	return r;
}
function withinPrice(price, range) {
	return range.min === null && range.max === null || price !== null && (range.min === null || price >= range.min) && (range.max === null || price <= range.max);
}
function brandMode(value) {
	if (value === void 0 || value === null || value === "" || value === "any") return "any";
	if (value === "same" || value === "other") return value;
	throw new Error("Некорректный режим бренда.");
}
function brandAllowed(a, b, mode) {
	if (mode === "any") return true;
	if (!a.brand || !b.brand) return false;
	return canonical(a.brand) === canonical(b.brand) === (mode === "same");
}
function ruleValue(p, r) {
	let v = field(p, r.keys);
	if (!v && r.kind === "gpu") v = p.name;
	if (!v && r.kind === "ports") v = Object.entries(p.specs).filter(([k, val]) => /^Количество (HDMI|DisplayPort|DVI|VGA)/i.test(k) && numeric(val) > 0).map(([k]) => k.replace("Количество ", "")).join(", ");
	if (!v && r.label === "Технология печати") {
		const n = normalize(p.name);
		if (/лазерн/.test(n)) v = "Лазерная";
		else if (/струйн/.test(n)) v = "Струйная";
	}
	return v;
}
function matrix(s) {
	return canonical(s.replace(/fast |rapid |nano |advanced |tft /gi, "").replace(/ah-ips|ads-ips/i, "ips"));
}
function speed(s) {
	const n = normalize(s), v = numeric(s);
	return /гбит|gbps|gbit|\d\s*g\s*(?:медь|оптика)/.test(n) ? v * 1e3 : /кбит|kbps/.test(n) ? v / 1e3 : v;
}
function connector(s) {
	return normalize(s).replace(/display\s*port/g, "dp").replace(/displayport/g, "dp").replace(/\b\d+(?:\.\d+)?\s*(?:гбит|мбит|gbps|gbit|гб|g)(?:\/с)?/g, "").replace(/hdmi\s*\d+(?:\.\d+)?/g, "hdmi").replace(/usb\s*\d+(?:\.\d+)?/g, "usb").replace(/pci-e|pci express/g, "pcie").replace(/[^a-zа-я0-9+]/g, "");
}
function os(s) {
	const n = normalize(s);
	return /без ос|не установлена|dos/.test(n) ? "no-os" : n.match(/windows|android|ios|linux|macos|astra|redos|ред ос/)?.[0] || canonical(s);
}
function valuesEqual(a, b, r) {
	if (r.kind === "resolution") return resolution(a) === resolution(b);
	if (r.kind === "matrix") return matrix(a) === matrix(b);
	if (r.kind === "ddr") return ddr(a) === ddr(b);
	if (r.kind === "form") return canonical(a) === canonical(b);
	if (r.kind === "connector") return connector(a) === connector(b);
	if (r.kind === "os") return os(a) === os(b);
	return canonical(a) === canonical(b);
}
var strictCategories = new Set([
	"battery",
	"ink",
	"toner",
	"cartridge",
	"adapter",
	"cable",
	"mount"
]);
function compareProducts(source, candidate) {
	const f = family(source), profile = profileFor(source);
	if (sameProduct(source, candidate) || candidate.stock !== "in" || f !== family(candidate) || source.city && candidate.city && source.city !== candidate.city) return null;
	if ((!profile || strictCategories.has(f)) && source.category && candidate.category && source.category !== candidate.category) return null;
	const reasons = [], missing = [], differences = [];
	const explained = /* @__PURE__ */ new Set();
	let earned = 0, total = 0, evidence = 0, criticalKnown = 0, importantMisses = 0;
	const rs = rulesFor(source);
	for (const r of rs) {
		const a = ruleValue(source, r), b = ruleValue(candidate, r);
		if (!a) {
			if (r.required || r.priority === "critical") missing.push(r.label + ": нет данных у исходного");
			continue;
		}
		total += r.weight;
		if (!b) {
			if (r.priority !== "secondary" || r.required) missing.push(r.label + ": нет данных у аналога");
			continue;
		}
		evidence++;
		let equivalent = valuesEqual(a, b, r), okay = equivalent, closeness = equivalent ? 1 : 0, forceReview = false;
		if (r.kind === "gpu") {
			const x = gpuChip(a), y = gpuChip(b);
			if (!x || !y) {
				const av = field(source, r.keys), bv = field(candidate, r.keys);
				if (!av || !bv) {
					missing.push("Модель графического процессора: нет точных данных");
					continue;
				}
				okay = equivalent = canonical(av.replace(/nvidia|geforce|amd|radeon|intel/gi, "")) === canonical(bv.replace(/nvidia|geforce|amd|radeon|intel/gi, ""));
			} else okay = equivalent = x === y;
			closeness = equivalent ? 1 : 0;
		}
		if (r.kind === "capacity" || r.kind === "minimum" || r.kind === "speed") {
			const av = r.kind === "capacity" ? capacity(a) : r.kind === "speed" ? speed(a) : numeric(a), bv = r.kind === "capacity" ? capacity(b) : r.kind === "speed" ? speed(b) : numeric(b);
			if (!Number.isFinite(av) || !Number.isFinite(bv) || av <= 0) {
				missing.push(r.label + ": не удалось сопоставить единицы");
				continue;
			}
			const ratio = bv / av;
			equivalent = Math.abs(ratio - 1) < .005;
			okay = ratio >= (r.floor ?? (r.priority === "critical" ? 1 : 0));
			closeness = equivalent ? 1 : ratio >= 1 ? .94 : Math.max(0, ratio * .8);
			if (ratio < 1) forceReview = true;
			if (r.label === "Длина" && ratio > 1) {
				closeness = 1 / (1 + Math.abs(Math.log(ratio)) * .6);
				if (ratio > 1.5) forceReview = true;
			}
			if (!okay && r.priority === "important" && r.floor !== void 0) return null;
		}
		if (r.kind === "diagonal") {
			const delta = Math.abs(numeric(a) - numeric(b));
			if (!Number.isFinite(delta)) {
				missing.push(r.label + ": нет числовых данных");
				continue;
			}
			okay = delta <= (r.tolerance ?? .5);
			equivalent = delta < .01;
			closeness = okay ? Math.max(.65, 1 - delta / (r.tolerance || .5) * .25) : 0;
		}
		if (r.kind === "ports") {
			const x = ports(a), y = ports(b);
			okay = x.every((v) => y.includes(v));
			equivalent = okay && y.length === x.length;
			closeness = okay ? 1 : 0;
		}
		if (r.kind === "set") {
			const x = tokens(a), y = tokens(b);
			okay = x.every((v) => y.includes(v));
			equivalent = okay && y.every((v) => x.includes(v));
			closeness = okay ? 1 : x.filter((v) => y.includes(v)).length / Math.max(1, x.length);
		}
		if (r.kind === "processor") {
			equivalent = canonical(a) === canonical(b);
			okay = true;
			closeness = equivalent ? 1 : .25;
			if (!equivalent) {
				missing.push(r.label + ": сравнить производительность " + a + " и " + b);
				forceReview = true;
			}
		}
		if (!okay && r.priority === "critical") return null;
		if (okay) {
			earned += r.weight * closeness;
			if (r.priority === "critical") criticalKnown++;
			reasons.push(r.label + ": " + b);
		} else {
			importantMisses++;
			if (r.priority === "important") missing.push(r.label + ": " + a + " → " + b);
		}
		if (!equivalent) {
			const line = r.label + ": " + a + " → " + b + (r.kind === "diagonal" && okay ? " (близкий размер)" : "");
			differences.push(line);
			for (const k of r.keys) explained.add(normalize(k));
			if (forceReview && r.kind !== "processor") missing.push(r.label + ": " + b);
		}
	}
	if (!profile && (evidence < 2 || criticalKnown < 1 || earned / Math.max(1, total) < .55)) return null;
	if (profile && evidence < 2) return null;
	if (!profile) missing.push("Категория без специального профиля: проверить назначение и совместимость");
	if (profile?.review) missing.push(profile.review);
	if (source.brand && candidate.brand && canonical(source.brand) !== canonical(candidate.brand)) differences.push("Бренд: " + source.brand + " → " + candidate.brand);
	const secondary = [];
	for (const [k, v] of Object.entries(source.specs)) {
		const b = field(candidate, [k]);
		if (b && !explained.has(normalize(k)) && canonical(v) !== canonical(b) && !rs.some((r) => r.keys.some((key) => normalize(key) === normalize(k)))) secondary.push(k + ": " + v + " → " + b);
	}
	differences.push(...secondary);
	if (f === "motherboard" && /(?:btf|project zero|stealth)/i.test(source.name + " " + candidate.name)) missing.push("Расположение разъёмов питания и совместимость с корпусом");
	const confidence = earned / Math.max(1, total);
	if (profile && criticalKnown === 0) missing.push("Критические параметры не подтверждены");
	const technical = confidence * 100 - importantMisses * 4 - Math.min(12, missing.length * 2);
	const pricePenalty = source.price && candidate.price ? Math.min(2, Math.abs(Math.log(candidate.price / source.price))) : 0;
	return {
		product: candidate,
		level: missing.length ? "review" : "matched",
		reasons: [...new Set(reasons)],
		differences: [...new Set(differences)],
		missing: [...new Set(missing)],
		score: Math.round((technical - pricePenalty) * 100) / 100
	};
}
function queriesFor(p) {
	const profile = profileFor(p), f = profile?.id;
	const out = [];
	if (f === "gpu") {
		const chip = gpuChip(field(p, ["Графический процессор"]) || p.name);
		if (chip) out.push("Видеокарта " + chip);
	} else if (f === "motherboard") out.push([
		"Материнская плата",
		field(p, ["Сокет", "Socket"]),
		field(p, ["Тип поддерживаемой памяти", "Тип памяти"])
	].filter(Boolean).join(" "));
	else if (f === "ssd" || f === "hdd" || f === "external-drive" || f === "memory-card") out.push([
		profile.label,
		field(p, ["Объем накопителя", "Объем"]),
		field(p, ["Интерфейс", "Интерфейс подключения"])
	].filter(Boolean).join(" "));
	else if (f === "monitor" || f === "tv" || f === "projector") out.push([profile.label, field(p, [
		"Разрешение",
		"Разрешение экрана",
		"Максимальное разрешение"
	])].filter(Boolean).join(" "));
	else if ([
		"cartridge",
		"toner",
		"ink"
	].includes(f || "")) {
		const models = field(p, ["Совместимость с моделями", "Совместимость"]);
		if (models) out.push(profile.label + " " + models.split(/[,;]/)[0]);
	} else {
		const technical = rulesFor(p).filter((r) => r.priority === "critical").map((r) => ruleValue(p, r)).filter((v) => v && v.length < 45).slice(0, 2);
		if (technical.length) out.push([profile?.label || p.categoryName || "", ...technical].join(" "));
	}
	const broad = p.categoryName || profile?.label || p.name.replace(p.brand || "", "").replace(/\[[^\]]+\]/g, "").split(" ").slice(0, 3).join(" ");
	if (broad) out.push(broad);
	return [...new Set(out.map((s) => clean(s).slice(0, 220)).filter(Boolean))].slice(0, 3);
}
function summaryScore(p, c) {
	const text = normalize(c.name + " " + c.description), profile = profileFor(p);
	let score = family({ name: c.name }) === family(p) ? 5 : 0;
	for (const r of rulesFor(p)) {
		const v = field(p, r.keys);
		if (!v) continue;
		if (r.kind === "gpu") {
			const chip = gpuChip(v);
			score += chip && gpuChip(c.name) === chip ? 100 : -100;
		} else if (r.kind === "resolution") {
			if (resolution(text).includes(resolution(v))) score += 25;
		} else if (r.kind === "ddr") {
			if (text.includes(ddr(v))) score += 20;
		} else if (v.length < 45 && canonical(text).includes(canonical(v))) score += r.weight;
	}
	if (profile?.id === "monitor") {
		const a = numeric(field(p, ["Диагональ экрана", "Диагональ"])), b = numeric(c.name.replace(/^Монитор\s*/i, ""));
		if (Number.isFinite(a) && Number.isFinite(b)) score -= Math.abs(a - b) * 3;
	}
	return score;
}
//#endregion
//#region lib/xcom/transport.ts
var UPSTREAM = new Set([
	"www.xcom-shop.ru",
	"xcom-shop.ru",
	"spb.xcom-shop.ru",
	"cdn.xcomweb.ru",
	"sort.diginetica.net"
]);
var SourceError = class extends Error {
	stage;
	status;
	constructor(message, stage, status) {
		super(message);
		this.name = "SourceError";
		this.stage = stage;
		this.status = status;
	}
};
var retryStatuses = new Set([
	502,
	503,
	504
]);
async function fetchText(input, timeout = 14e3) {
	let final;
	for (let attempt = 0; attempt < 2; attempt++) try {
		let url = new URL(input);
		for (let redirects = 0; redirects < 4; redirects++) {
			if (url.protocol !== "https:" || !UPSTREAM.has(url.hostname) || url.username || url.password || url.port) throw new SourceError("Источник вернул неподдерживаемый адрес.", "redirect");
			const remaining = remainingRequestTime();
			if (remaining < 100) throw new SourceError("Проверка продолжается: достигнут лимит времени одного запроса.", "budget");
			const r = await fetch(url, {
				headers: {
					Accept: "text/html,application/json",
					"User-Agent": "XcomAnalogs/1.2 (catalog lookup)"
				},
				signal: AbortSignal.timeout(Math.max(1, Math.floor(Math.min(remaining, attempt ? Math.min(timeout, 9e3) : timeout)))),
				redirect: "manual"
			});
			if ([
				301,
				302,
				303,
				307,
				308
			].includes(r.status)) {
				const target = r.headers.get("location");
				if (!target) throw new SourceError("Не удалось открыть перенаправление XCOM-SHOP.", "redirect");
				url = new URL(target, url);
				continue;
			}
			if (!r.ok) {
				if (attempt === 0 && retryStatuses.has(r.status)) throw new SourceError("Магазин временно недоступен.", "retry", r.status);
				throw new SourceError(r.status === 429 ? "XCOM-SHOP временно ограничил частоту запросов. Повторите проверку позже." : "Источник XCOM-SHOP сейчас недоступен (" + r.status + "). Повторите позже.", "http", r.status);
			}
			const body = await r.text();
			if (body.length > 65e5) throw new SourceError("Ответ каталога слишком большой. Уточните товар.", "size");
			return body;
		}
		throw new SourceError("Слишком много перенаправлений XCOM-SHOP.", "redirect");
	} catch (e) {
		final = remainingRequestTime() < 100 ? new SourceError("Проверка продолжается: достигнут лимит времени одного запроса.", "budget") : e;
		const retry = final instanceof SourceError ? final.stage === "retry" : true;
		if (attempt || !retry) break;
		await new Promise((resolve) => setTimeout(resolve, 180));
	}
	console.warn(JSON.stringify({
		event: "xcom_source_error",
		stage: final instanceof SourceError ? final.stage : "network",
		status: final instanceof SourceError ? final.status : void 0,
		host: new URL(input).hostname
	}));
	if (final instanceof SourceError) throw final;
	throw new SourceError("Не удалось получить ответ XCOM-SHOP. Проверьте подключение или повторите запрос позже.", "network");
}
var TimedCache = class {
	entries = /* @__PURE__ */ new Map();
	ttl;
	max;
	constructor(ttl, max) {
		this.ttl = ttl;
		this.max = max;
	}
	get(key, fetcher, fresh = false) {
		const hit = this.entries.get(key);
		if (!fresh && hit && hit.expires > Date.now()) return hit.value;
		if (hit) this.entries.delete(key);
		while (this.entries.size >= this.max) this.entries.delete(this.entries.keys().next().value);
		const value = fetcher().catch((e) => {
			if (this.entries.get(key)?.value === value) this.entries.delete(key);
			throw e;
		});
		this.entries.set(key, {
			value,
			expires: Date.now() + this.ttl
		});
		return value;
	}
	clear() {
		this.entries.clear();
	}
};
//#endregion
//#region lib/xcom/catalog.ts
var CITIES = {
	msk: {
		name: "Москва",
		origin: "https://www.xcom-shop.ru",
		region: "1"
	},
	spb: {
		name: "Санкт-Петербург",
		origin: "https://spb.xcom-shop.ru",
		region: "2"
	}
};
function cityValue(value) {
	if (value === null || value === "msk") return "msk";
	if (value === "spb") return "spb";
	throw new Error("Выберите Москву или Санкт-Петербург.");
}
var HOSTS = [
	"xcom-shop.ru",
	"www.xcom-shop.ru",
	"spb.xcom-shop.ru"
];
function productUrl(input, city) {
	const u = new URL(input, CITIES[city || "msk"].origin);
	if (!HOSTS.includes(u.hostname) || u.protocol !== "https:" || u.username || u.password || u.port || !/^\/[a-zA-Z0-9_.+%-]+_\d+\.html$/.test(u.pathname)) throw new Error("Нужна ссылка на карточку XCOM-SHOP (Москва или Санкт-Петербург).");
	return (city ? CITIES[city].origin : u.hostname === "spb.xcom-shop.ru" ? CITIES.spb.origin : CITIES.msk.origin) + u.pathname;
}
function imageUrl(input) {
	const u = new URL(input);
	if (u.protocol !== "https:" || u.hostname !== "cdn.xcomweb.ru" || u.username || u.password || u.port || !/^\/upload\/(?:main_picture|pictures)\//.test(u.pathname)) throw new Error("Изображение вне каталога XCOM.");
	return u.href;
}
function attr(s, key) {
	return s.match(new RegExp("\\b" + key + "=[\"']([^\"']*)[\"']", "i"))?.[1] || "";
}
function meta(html, key) {
	for (const m of html.matchAll(/<(?:meta|link)\b[^>]*>/gi)) if (attr(m[0], "itemprop") === key) return clean(attr(m[0], "content") || attr(m[0], "href"));
	return "";
}
function divBlock(html, pattern) {
	const start = html.match(pattern);
	if (start?.index === void 0) return "";
	let depth = 0;
	const tail = html.slice(start.index);
	for (const token of tail.matchAll(/<\/?div\b[^>]*>/gi)) {
		depth += /^<\//.test(token[0]) ? -1 : 1;
		if (depth === 0) return tail.slice(0, token.index + token[0].length);
	}
	return "";
}
function parseProduct(html, url) {
	const schema = divBlock(html, /<div\b[^>]*itemtype=["'](?:https?:)?\/\/schema\.org\/Product["'][^>]*>/i);
	if (!schema && /<main\b[^>]*id="card"/.test(html)) throw new Error("Не удалось прочитать основные данные карточки XCOM-SHOP.");
	const metadata = schema || html;
	const name = clean(html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1] || "").replace(/\s+в (?:Санкт-Петербург[еe]|Москве)$/i, "");
	const id = meta(metadata, "sku") || html.match(/data-fl-item-id="(\d+)"/)?.[1] || "";
	if (!name || !/^\d+$/.test(id) || !url.includes("_" + id + ".html")) throw new Error("Магазин не вернул полную карточку товара. Повторите проверку или попробуйте другую ссылку.");
	const specs = {};
	for (const m of html.matchAll(/<li\b[^>]*class="[^"\n]*\bcard-tabs-props-list-item\b[^"\n]*"[^>]*>([\s\S]*?)<\/li>/g)) {
		const k = clean(m[1].match(/class="card-tabs-props-list-item__label"[^>]*>([\s\S]*?)<\/div>/)?.[1] || "");
		const v = clean(m[1].match(/class="card-tabs-props-list-item__value"[^>]*>([\s\S]*?)<\/div>/)?.[1] || "");
		if (k && v) specs[k] = v;
	}
	const availability = meta(metadata, "availability");
	const quantity = clean(divBlock(html, /<div\b[^>]*class="[^"]*stock-indicator--card[^"]*"[^>]*>/i).match(/Количество товара на складах:[\s\S]{0,250}?class="[^"]*"[^>]*>([^<]+)/)?.[1] || "");
	const stock = availability.endsWith("InStock") ? "in" : /OutOfStock|Discontinued|SoldOut/.test(availability) ? "out" : "unknown";
	const qty = quantity.match(/(\d+)/);
	const minimumQuantity = qty ? Number(qty[1]) + (/более/.test(quantity) ? 1 : 0) : null;
	const crumbs = [...html.matchAll(/<a\b[^>]*href="(\/catalog\/[^"?#]*)"[^>]*class="card-path__link"[^>]*>([\s\S]*?)<\/a>/g)].map((m) => ({
		url: m[1],
		name: clean(m[2])
	}));
	const brand = meta(metadata, "brand");
	if (crumbs.length && normalize(crumbs[crumbs.length - 1].name) === normalize(brand)) crumbs.pop();
	const category = crumbs.at(-1)?.url || "";
	const categoryName = crumbs.at(-1)?.name || "";
	const images = [];
	try {
		const image = imageUrl(meta(metadata, "image"));
		images.push(image);
	} catch {}
	const price = Number(meta(metadata, "price"));
	const city = new URL(url).hostname === "spb.xcom-shop.ru" ? "spb" : "msk";
	const delivery = clean(html.match(/class="card-content-total-info-item__text"[^>]*>Доставка:\s*([\s\S]*?)<\/div>/)?.[1] || "");
	const pickup = clean(html.match(/class="card-content-total-info-item__text"[^>]*>Самовывоз:\s*([\s\S]*?)<\/div>/)?.[1] || "");
	return {
		id,
		brand,
		name,
		article: clean(html.match(/card-sticky-code__item">Артикул:([\s\S]*?)<\/div>/)?.[1] || ""),
		url: productUrl(url, city),
		image: images[0] || "",
		images,
		price: Number.isFinite(price) && price > 0 ? price : null,
		stock,
		quantity,
		minimumQuantity,
		description: meta(metadata, "description") && meta(metadata, "description") !== "Array" ? meta(metadata, "description") : Object.entries(specs).slice(0, 5).map(([k, v]) => k + ": " + v).join(" · "),
		specs,
		category,
		categoryName,
		checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
		city,
		delivery,
		pickup
	};
}
var productCache = new TimedCache(3e4, 180);
async function loadProduct(url, city, fresh = false) {
	const safe = productUrl(url, city);
	return productCache.get(safe, async () => {
		const html = await fetchText(safe);
		const expected = new URL(safe).hostname === "spb.xcom-shop.ru" ? "2" : "1";
		if (html.match(/data-regional-id="(\d+)"/)?.[1] !== expected) throw new SourceError("Не удалось подтвердить выбранный город в карточке XCOM-SHOP. Повторите проверку.", "region");
		try {
			return parseProduct(html, safe);
		} catch {
			throw new SourceError("XCOM-SHOP не вернул полную карточку. Повторите проверку позже.", "parse");
		}
	}, fresh);
}
var configCache = new TimedCache(36e5, 1);
async function searchKey() {
	return configCache.get("public", async () => {
		const key = (await fetchText("https://cdn.xcomweb.ru/local/templates/shop2022/js/external_mod/diginetica/client.js?v=1")).match(/apiKey:"([A-Za-z0-9]+)"/)?.[1];
		if (!key) throw new SourceError("Поиск магазина изменился. Используйте прямую ссылку на товар.", "config");
		return key;
	});
}
var pageCache = new TimedCache(9e4, 64);
async function searchCatalogPage(query, size = 100, city = "msk", availableOnly = false, options = {}) {
	const offset = options.offset || 0;
	const count = Math.min(100, Math.max(1, size));
	const categories = options.categoryIds || [];
	const cacheKey = JSON.stringify([
		query,
		count,
		city,
		availableOnly,
		offset,
		!!options.correction,
		categories
	]);
	return pageCache.get(cacheKey, async () => {
		const u = new URL("https://sort.diginetica.net/search");
		for (const [k, v] of Object.entries({
			st: query,
			apiKey: await searchKey(),
			strategy: "advanced_xname,zero_queries",
			fullData: "true",
			withCorrection: options.correction ? "true" : "false",
			withFacets: categories.length ? "true" : "false",
			treeFacets: categories.length ? "true" : "false",
			regionId: CITIES[city].region,
			size: String(count),
			offset: String(offset),
			showUnavailable: availableOnly ? "false" : "true",
			sort: "DEFAULT"
		})) u.searchParams.set(k, v);
		if (categories.length) u.searchParams.set("filter", "categories:" + categories.join(";"));
		let j;
		try {
			j = JSON.parse(await fetchText(u.toString()));
		} catch (e) {
			if (e instanceof SourceError) throw e;
			throw new SourceError("Поиск XCOM-SHOP вернул некорректный ответ. Повторите позже.", "search_parse");
		}
		if (!Array.isArray(j.products) || !Number.isFinite(j.totalHits)) throw new SourceError("Структура ответа поиска XCOM-SHOP изменилась.", "search_schema");
		if (j.zeroQueries) return {
			items: [],
			total: 0,
			offset,
			nextOffset: null,
			correction: "",
			receivedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		return {
			items: j.products.flatMap((p) => {
				try {
					if (!/^\d+$/.test(String(p.id)) || typeof p.name !== "string") return [];
					return [{
						id: String(p.id),
						brand: typeof p.brand === "string" ? p.brand : void 0,
						name: p.name,
						url: productUrl(p.link_url, city),
						image: typeof p.image_url === "string" && /^https:\/\/cdn\.xcomweb\.ru\//.test(p.image_url) ? p.image_url : "",
						description: (p.attributes?.["мини-описание"] || []).filter((s) => typeof s === "string").join(" "),
						available: p.available === true,
						categories: Array.isArray(p.categories) ? p.categories.filter((c) => /^\d+$/.test(String(c.id)) && typeof c.name === "string").map((c) => ({
							id: String(c.id),
							name: c.name
						})) : []
					}];
				} catch {
					return [];
				}
			}),
			total: j.totalHits,
			offset,
			nextOffset: offset + j.products.length < j.totalHits && j.products.length ? offset + j.products.length : null,
			correction: typeof j.correction === "string" ? j.correction : "",
			receivedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
	});
}
async function resolveSearch(query, city = "msk") {
	const q = categoryTypo(inputQuery(query));
	let page = await searchCatalogPage(q, 30, city);
	if (/^\d+$/.test(q)) return {
		items: page.items.filter((p) => p.id === q),
		requiresSelection: false
	};
	const exact = page.items.filter((p) => {
		const article = p.name.match(/\[([^\]]+)\]/)?.[1];
		return normalize(article || "") === normalize(q) || normalize(p.name) === normalize(q);
	});
	if (exact.length) return {
		items: exact,
		requiresSelection: false
	};
	const intent = profileFor({
		name: q,
		category: ""
	});
	if (intent) page = {
		...page,
		items: page.items.filter((p) => profileFor({
			name: p.name,
			category: ""
		})?.id === intent.id)
	};
	let requiresSelection = false;
	if (!page.items.length) {
		page = await searchCatalogPage(q, 30, city, false, { correction: true });
		if (intent) page = {
			...page,
			items: page.items.filter((p) => profileFor({
				name: p.name,
				category: ""
			})?.id === intent.id)
		};
		requiresSelection = page.items.length > 0;
	}
	if (!page.items.length && intent) {
		const technical = q.replace(new RegExp("^" + intent.label + "\\s*", "i"), "").trim();
		if (technical.length >= 2 && technical !== q) {
			page = await searchCatalogPage(technical, 100, city, false, { correction: false });
			page = {
				...page,
				items: page.items.filter((p) => profileFor({
					name: p.name,
					category: ""
				})?.id === intent.id)
			};
			requiresSelection = page.items.length > 0;
		}
		if (!page.items.length && technical.length >= 2 && technical !== q) {
			const broad = await searchCatalogPage(intent.label, 100, city);
			const term = normalize(technical).replace(/[^a-zа-я0-9]/g, "");
			page = {
				...broad,
				items: broad.items.filter((p) => profileFor({
					name: p.name,
					category: ""
				})?.id === intent.id && normalize(p.name + " " + p.description).replace(/[^a-zа-я0-9]/g, "").includes(term))
			};
			requiresSelection = page.items.length > 0;
		}
	}
	return {
		items: page.items,
		requiresSelection
	};
}
function validateCursor(value, source, city, plan) {
	if (value === void 0 || value === null) return null;
	const c = value;
	if (!Number.isInteger(c.page) || c.page < 0 || c.page > 1e5 || c.city !== city || c.sourceId !== source.id || c.plan !== plan || !Array.isArray(c.seen) || c.seen.length > 1e5 || c.seen.some((x) => typeof x !== "string" || !/^\d{1,16}$/.test(x))) throw new Error("Настройки подбора изменились. Запустите поиск заново.");
	return {
		...c,
		seen: [...new Set(c.seen)]
	};
}
async function findAnalogs(source, range, quantity, city = "msk", offset = 0, mode = "any", cursorInput, freshCards = false) {
	const queries = queriesFor(source);
	const plan = JSON.stringify([
		queries,
		source.category,
		source.brand,
		source.name,
		source.specs,
		range,
		quantity,
		mode
	]);
	const cursor = validateCursor(cursorInput, source, city, plan);
	let page = cursor?.page || 0;
	const seen = new Set(cursor?.seen || []);
	const deadline = Math.min(Date.now() + 52e3, requestDeadline() - 1e3);
	let categoryIds = [];
	let categoryLookupFailed = false;
	try {
		categoryIds = (await searchCatalogPage(source.id, 1, city)).items.find((p) => p.id === source.id)?.categories?.map((c) => c.id) || [];
	} catch {
		categoryLookupFailed = true;
	}
	const requests = queries.map((query) => ({
		query,
		categoryIds
	}));
	let candidates = [], hasMorePages = false, searchFailed = 0;
	let errors = [];
	for (let skip = 0; skip < 3; skip++) {
		const pages = await Promise.allSettled([...requests.map((r) => searchWindow(r.query, page, city, r.categoryIds)), ...source.category ? [categoryWindow(source.category, page, city)] : []]);
		const pool = /* @__PURE__ */ new Map();
		hasMorePages = false;
		searchFailed = 0;
		errors = [];
		for (const r of pages) {
			if (r.status === "rejected") {
				searchFailed++;
				errors.push(r.reason);
				continue;
			}
			hasMorePages ||= r.value.nextOffset !== null;
			for (const p of r.value.items) if (p.available !== false && p.id !== source.id && !seen.has(p.id)) pool.set(p.id, p);
		}
		if (searchFailed === pages.length) throw errors[0] || new SourceError("Каталог XCOM-SHOP недоступен.", "search");
		for (const [id, p] of pool) {
			const known = profileFor({
				name: p.name,
				category: ""
			}), wanted = profileFor(source);
			if (known && wanted && known.id !== wanted.id) {
				seen.add(id);
				pool.delete(id);
			} else if (wanted?.id === "gpu") {
				const chip = gpuChip(p.name), original = gpuChip(field(source, ["Графический процессор"]) || source.name);
				if (chip && original && chip !== original) {
					seen.add(id);
					pool.delete(id);
				}
			}
		}
		candidates = [...pool.values()].sort((a, b) => summaryScore(source, b) - summaryScore(source, a) || a.id.localeCompare(b.id));
		if (candidates.length || !hasMorePages) break;
		if (skip < 2) page++;
	}
	if (!cursor && offset > 0) {
		for (const p of candidates.slice(0, offset)) seen.add(p.id);
		candidates = candidates.slice(offset);
	}
	const list = candidates.slice(0, 96);
	const matches = [];
	let checked = 0, failed = 0, qtyExcluded = 0, unavailable = 0, incompatible = 0, budgetExcluded = 0, brandExcluded = 0, processed = 0, budgetDeferred = 0;
	for (let i = 0; i < list.length && Date.now() < deadline; i += 4) {
		if (i >= 32 && matches.length >= 6) break;
		const batch = list.slice(i, i + 4);
		const results = await Promise.allSettled(batch.map((x) => loadProduct(x.url, city, freshCards)));
		for (let j = 0; j < results.length; j++) {
			const r = results[j];
			if (r.status === "rejected" && r.reason instanceof SourceError && r.reason.stage === "budget") {
				budgetDeferred++;
				continue;
			}
			seen.add(batch[j].id);
			processed++;
			if (r.status === "rejected") {
				failed++;
				continue;
			}
			checked++;
			const p = r.value;
			if (p.stock !== "in") {
				unavailable++;
				continue;
			}
			if (!withinPrice(p.price, range)) {
				budgetExcluded++;
				continue;
			}
			if (!brandAllowed(source, p, mode)) {
				brandExcluded++;
				continue;
			}
			if (quantity > 1 && (p.minimumQuantity === null || p.minimumQuantity < quantity)) {
				qtyExcluded++;
				continue;
			}
			const m = compareProducts(source, p);
			if (m) matches.push(m);
			else incompatible++;
		}
	}
	matches.sort((a, b) => b.score - a.score || a.product.id.localeCompare(b.product.id));
	const next = candidates.length > processed ? {
		page,
		seen: [...seen],
		sourceId: source.id,
		city,
		plan
	} : hasMorePages ? {
		page: page + 1,
		seen: [...seen],
		sourceId: source.id,
		city,
		plan
	} : null;
	return {
		matches,
		checked,
		failed,
		qtyExcluded,
		pool: seen.size + Math.max(0, candidates.length - processed),
		limited: !!next,
		nextOffset: next ? seen.size : null,
		nextCursor: next,
		scanned: seen.size,
		checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
		supported: !!profileFor(source),
		city,
		diagnostics: {
			unavailable,
			incompatible,
			budgetExcluded,
			brandExcluded,
			searchFailed,
			categoryLookupFailed
		},
		queries,
		catalogHasMore: hasMorePages,
		coverage: next || searchFailed || failed ? "partial" : "searched",
		sourceWarning: budgetDeferred ? "Проверка ограничена временем одного запроса. Продолжите подбор, чтобы проверить оставшиеся товары." : !profileFor(source) && !matches.length ? "Недостаточно проверенных технических данных для уверенного подбора в этой категории. Аналоги не подтверждены." : searchFailed ? "Часть поисковых запросов XCOM-SHOP не ответила. Полнота подбора не подтверждена." : categoryLookupFailed ? "Категорию не удалось подтвердить в поисковом индексе. Использованы характеристики и категория карточки." : !categoryIds.length ? "Товар не найден по коду в поисковом индексе: поиск выполнен по категории и характеристикам карточки." : ""
	};
}
function categoryUrl(path, city) {
	const u = new URL(path, CITIES[city].origin);
	if (u.origin !== CITIES[city].origin || !/^\/catalog\/[a-zA-Z0-9_./%-]+\/$/.test(u.pathname) || u.search || u.hash) throw new SourceError("Некорректная категория XCOM-SHOP.", "category_url");
	return u.href;
}
function parseCatalogPage(html, url, city) {
	if (html.match(/data-regional-id="(\d+)"/)?.[1] !== CITIES[city].region) throw new SourceError("Город категории XCOM-SHOP не подтверждён.", "region");
	const base = new URL(url);
	const offset = Number(base.searchParams.get("catalog")?.match(/^page-(\d+)$/)?.[1] || 1) - 1;
	const current = Number(html.match(/data-current-page="(\d+)"/)?.[1] || 1);
	const total = Number(html.match(/data-total-pages="(\d+)"/)?.[1] || 1);
	if (current !== offset + 1) throw new SourceError("XCOM-SHOP вернул другую страницу каталога.", "category_pagination");
	const cards = [...html.matchAll(/<div\b(?=[^>]*class="catalog_item\s)[^>]*>/g)];
	if (!cards.length && !/id="catalog-list"/.test(html)) throw new SourceError("Не удалось прочитать список товаров категории XCOM-SHOP.", "category_parse");
	const items = [];
	for (let i = 0; i < cards.length; i++) {
		const head = cards[i][0], block = html.slice(cards[i].index + head.length, cards[i + 1]?.index || html.indexOf("catalog-pagination", cards[i].index + head.length));
		const a = block.match(/<a\b[^>]*class="catalog_item__name\b[^"\n]*"[^>]*>([\s\S]*?)<\/a>/);
		const id = attr(head, "data-id");
		if (!a || !/^\d+$/.test(id)) continue;
		try {
			const name = clean(a[1]);
			items.push({
				id,
				brand: clean(attr(head, "data-vendor")),
				name,
				url: productUrl(clean(attr(a[0], "href")), city),
				image: "",
				description: clean(block.match(/class="catalog_item__description\b[^"\n]*"[^>]*>([\s\S]*?)<\/div>/)?.[1] || ""),
				available: void 0
			});
		} catch {}
	}
	return {
		items,
		pageCount: total,
		total: total * Number(html.match(/data-show-count="(\d+)"/)?.[1] || 24),
		offset,
		nextOffset: current < total ? current : null,
		correction: "",
		receivedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
var categoryCache = new TimedCache(9e4, 40);
async function categoryCatalogPage(path, page, city) {
	const base = categoryUrl(path, city);
	const first = await categoryCache.get(base, async () => {
		const html = await fetchText(base);
		const data = parseCatalogPage(html, base, city);
		let template = "";
		for (const m of html.matchAll(/<a\b[^>]*class="catalog-pagination__page"[^>]*>/g)) {
			const href = clean(attr(m[0], "href"));
			const u = new URL(href, base);
			if (u.origin === CITIES[city].origin && u.pathname === new URL(base).pathname && /^\?catalog=page-\d+$/.test(u.search)) {
				template = u.href;
				break;
			}
		}
		if (data.nextOffset !== null && !template) throw new SourceError("Не удалось найти следующую страницу категории XCOM-SHOP.", "category_pagination");
		return {
			data,
			template
		};
	});
	if (page === 0) return first.data;
	if (!first.template || page >= (first.data.pageCount || 1)) return {
		...first.data,
		items: [],
		offset: page,
		nextOffset: null
	};
	const u = new URL(first.template);
	u.searchParams.set("catalog", "page-" + (page + 1));
	return (await categoryCache.get(u.href, async () => ({
		data: parseCatalogPage(await fetchText(u.href), u.href, city),
		template: first.template
	}))).data;
}
async function searchWindow(query, page, city, categoryIds) {
	const first = await searchCatalogPage(query, 100, city, true, {
		offset: page * 200,
		categoryIds
	});
	if (first.nextOffset === null) return first;
	const second = await searchCatalogPage(query, 100, city, true, {
		offset: page * 200 + 100,
		categoryIds
	});
	return {
		...second,
		items: [...first.items, ...second.items]
	};
}
async function categoryWindow(path, page, city) {
	const first = await categoryCatalogPage(path, page * 2, city);
	if (first.nextOffset === null) return first;
	const second = await categoryCatalogPage(path, page * 2 + 1, city);
	return {
		...second,
		items: [...first.items, ...second.items]
	};
}
//#endregion
//#region app/api/search/route.ts
async function GET$2(request) {
	try {
		const params = new URL(request.url).searchParams;
		const city = cityValue(params.get("city"));
		const q = params.get("q")?.trim() || "";
		if (q.length < 2 || q.length > 240) return Response.json({ error: "Введите код, артикул, название или ссылку (2–240 символов)." }, { status: 400 });
		if (/^https?:\/\//i.test(q)) {
			const product = await loadProduct(productUrl(q, city), city);
			return Response.json({ product }, { headers: { "Cache-Control": "no-store" } });
		}
		return Response.json(await resolveSearch(q, city), { headers: { "Cache-Control": "no-store" } });
	} catch (e) {
		return Response.json({ error: e instanceof Error ? e.message : "Не удалось выполнить поиск." }, { status: 502 });
	}
}
//#endregion
//#region app/api/analogs/route.ts
async function handle$1(body) {
	let city, url, range, mode;
	const quantity = Number(body.quantity || 1), offset = Number(body.offset || 0);
	try {
		city = cityValue(body.city === void 0 ? null : String(body.city));
		url = productUrl(String(body.url || ""), city);
		range = priceRange(body.priceMin === void 0 ? null : String(body.priceMin), body.priceMax === void 0 ? null : String(body.priceMax));
		mode = brandMode(body.brandMode);
		if (!Number.isInteger(quantity) || quantity < 1 || quantity > 1e4 || !Number.isInteger(offset) || offset < 0 || offset > 1e5) throw new Error("Проверьте количество товаров.");
		if (mode !== "any" && body.cursor && typeof body.cursor !== "object") throw new Error("Запустите подбор заново.");
	} catch (e) {
		return Response.json({ error: e instanceof Error ? e.message : "Проверьте параметры поиска." }, { status: 400 });
	}
	try {
		const source = await loadProduct(url, city, true);
		return Response.json({
			source,
			...await findAnalogs(source, range, quantity, city, offset, mode, body.cursor, body.fresh === true)
		}, { headers: { "Cache-Control": "no-store" } });
	} catch (e) {
		return Response.json({ error: e instanceof Error ? e.message : "Проверка товаров временно недоступна." }, { status: 502 });
	}
}
async function GET$1(request) {
	return handle$1(Object.fromEntries(new URL(request.url).searchParams));
}
async function POST(request) {
	try {
		const text = await request.text();
		if (text.length > 18e5) return Response.json({ error: "Слишком большой запрос. Запустите поиск заново." }, { status: 400 });
		const body = JSON.parse(text);
		if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error();
		return handle$1(body);
	} catch {
		return Response.json({ error: "Некорректный запрос подбора." }, { status: 400 });
	}
}
//#endregion
//#region app/api/image/route.ts
async function GET(request) {
	let src;
	try {
		src = imageUrl(new URL(request.url).searchParams.get("src") || "");
	} catch {
		return new Response("Недопустимый адрес изображения", { status: 400 });
	}
	const variants = [src, src.replace(/_\d+\.(?:webp|jpg|png)(?=$|\?)/i, "")].filter((v, i, a) => a.indexOf(v) === i);
	for (const url of variants) try {
		const r = await fetch(url, {
			redirect: "manual",
			headers: { Accept: "image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8" },
			signal: AbortSignal.timeout(18e3)
		});
		const type = r.headers.get("Content-Type")?.split(";")[0] || "";
		if (!r.ok || !/^image\/(jpeg|png|webp|gif|avif)$/i.test(type) || Number(r.headers.get("Content-Length") || 0) > 8e6) {
			await r.body?.cancel();
			continue;
		}
		const reader = r.body?.getReader();
		if (!reader) continue;
		const chunks = [];
		let length = 0;
		while (true) {
			const v = await reader.read();
			if (v.done) break;
			length += v.value.length;
			if (length > 8e6) {
				await reader.cancel();
				break;
			}
			chunks.push(v.value);
		}
		if (length > 8e6 || length === 0) continue;
		const output = new Uint8Array(length);
		let at = 0;
		for (const c of chunks) {
			output.set(c, at);
			at += c.length;
		}
		return new Response(output, { headers: {
			"Content-Type": type,
			"Cache-Control": "public,max-age=86400",
			"X-Content-Type-Options": "nosniff"
		} });
	} catch {}
	return new Response("Фотография временно недоступна", {
		status: 404,
		headers: { "Cache-Control": "public,max-age=60" }
	});
}
//#endregion
//#region standalone/server.ts
var directory = resolve(fileURLToPath(new URL("../public/", import.meta.url)));
var types = {
	".html": "text/html; charset=utf-8",
	".js": "text/javascript; charset=utf-8",
	".css": "text/css; charset=utf-8",
	".json": "application/json",
	".webmanifest": "application/manifest+json",
	".svg": "image/svg+xml",
	".png": "image/png",
	".webp": "image/webp",
	".jpg": "image/jpeg",
	".ico": "image/x-icon",
	".woff2": "font/woff2"
};
var active = 0;
async function send(res, response, head = false) {
	res.writeHead(response.status, Object.fromEntries(response.headers));
	if (!head && response.body) res.end(Buffer.from(await response.arrayBuffer()));
	else res.end();
}
async function handle(req, res) {
	const method = req.method || "GET", url = new URL(req.url || "/", "http://localhost");
	if (url.pathname === "/healthz") {
		res.writeHead(200, { "Content-Type": "application/json" });
		res.end("{\"ok\":true}");
		return;
	}
	if (url.pathname.startsWith("/api/")) {
		if (!["GET", "POST"].includes(method)) {
			res.writeHead(405);
			res.end();
			return;
		}
		const handler = url.pathname === "/api/search" && method === "GET" ? GET$2 : url.pathname === "/api/image" && method === "GET" ? GET : url.pathname === "/api/analogs" ? method === "POST" ? POST : GET$1 : null;
		if (!handler) {
			res.writeHead(404);
			res.end();
			return;
		}
		if (active >= 4) {
			await send(res, Response.json({ error: "Сервис сейчас проверяет другие товары. Повторите запрос чуть позже." }, { status: 429 }));
			return;
		}
		active++;
		try {
			const chunks = [];
			let bytes = 0;
			for await (const chunk of req) {
				const b = Buffer.from(chunk);
				bytes += b.length;
				if (bytes > 18e5) {
					await send(res, Response.json({ error: "Слишком большой запрос." }, { status: 413 }));
					return;
				}
				chunks.push(b);
			}
			await send(res, await handler(new Request(url, {
				method,
				headers: { "Content-Type": "application/json" },
				...method === "POST" ? { body: Buffer.concat(chunks).toString("utf8") } : {}
			})));
		} finally {
			active--;
		}
		return;
	}
	if (!["GET", "HEAD"].includes(method)) {
		res.writeHead(405);
		res.end();
		return;
	}
	let name;
	try {
		name = decodeURIComponent(url.pathname);
	} catch {
		res.writeHead(400);
		res.end();
		return;
	}
	const file = resolve(directory, "." + (name === "/" ? "/index.html" : name));
	if (!file.startsWith(directory + sep)) {
		res.writeHead(404);
		res.end();
		return;
	}
	try {
		if (!(await stat(file)).isFile()) throw new Error();
		const body = await readFile(file);
		res.writeHead(200, {
			"Content-Type": types[extname(file)] || "application/octet-stream",
			"Content-Length": body.length,
			"X-Content-Type-Options": "nosniff",
			"Cache-Control": file.endsWith(".html") ? "no-store" : "public,max-age=3600"
		});
		res.end(method === "HEAD" ? void 0 : body);
	} catch {
		res.writeHead(404);
		res.end();
	}
}
var server = createServer((req, res) => {
	withRequestBudget(48e3, () => handle(req, res)).catch(() => {
		if (!res.headersSent) res.writeHead(500, { "Content-Type": "application/json" });
		res.end("{\"error\":\"Ошибка сервера. Повторите запрос позже.\"}");
	});
});
server.requestTimeout = 18e4;
server.listen(Number(process.env.PORT || 1e4), "0.0.0.0", () => console.log("XCOM Analogs server ready"));
//#endregion
export {};
